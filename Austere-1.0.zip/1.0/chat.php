<?php
// KEY CHANGE: This single line is the most important change.
// It ensures the script continues to run and save the chat
// even if the user closes the browser.
ignore_user_abort(true);

header('Content-Type: text/event-stream');
header('Cache-Control: no-cache');
header('Connection: keep-alive');
header('X-Accel-Buffering: no'); // Nginx: specific header to disable buffering

// For local development, allow cross-origin requests
// header('Access-Control-Allow-Origin: *'); 

$historyFile = 'history.json';

// Function to load all chats from the file
function loadChats($file) {
    if (!file_exists($file)) {
        return [];
    }
    $json = file_get_contents($file);
    return json_decode($json, true);
}

// Function to save all chats to the file
function saveChats($file, $chats) {
    uasort($chats, function($a, $b) {
        return ($b['lastUpdated'] ?? 0) <=> ($a['lastUpdated'] ?? 0);
    });
    $json = json_encode($chats, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    file_put_contents($file, $json, LOCK_EX);
}

// ==========================================================
// API-like request handling based on 'action' parameter
// ==========================================================

$action = $_GET['action'] ?? null;

if ($action === 'load') {
    header('Content-Type: application/json');
    $chats = loadChats($historyFile);
    $summary = [];
    foreach ($chats as $id => $chat) {
        $summary[] = [
            'id' => $id,
            'title' => $chat['title'] ?? '未命名对话',
            'history' => $chat['history'],
            'lastUpdated' => $chat['lastUpdated'] ?? 0
        ];
    }
    usort($summary, function($a, $b) {
        return $b['lastUpdated'] <=> $a['lastUpdated'];
    });

    echo json_encode($summary);
    exit;
}

if ($action === 'delete') {
    header('Content-Type: application/json');
    $chatId = $_GET['chatId'] ?? null;
    if ($chatId) {
        $chats = loadChats($historyFile);
        if (isset($chats[$chatId])) {
            unset($chats[$chatId]);
            saveChats($historyFile, $chats);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Chat not found']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'No chat ID provided']);
    }
    exit;
}

if ($action === 'update_title') {
    header('Content-Type: application/json');
    
    $chatId = $_POST['chatId'] ?? null;
    $newTitle = $_POST['newTitle'] ?? null;

    if ($chatId && $newTitle) {
        $chats = loadChats($historyFile);

        if (isset($chats[$chatId])) {
            $chats[$chatId]['title'] = trim($newTitle);
            $chats[$chatId]['lastUpdated'] = time();
            saveChats($historyFile, $chats);
            echo json_encode(['success' => true]);
        } else {
            echo json_encode(['success' => false, 'error' => 'Chat not found']);
        }
    } else {
        echo json_encode(['success' => false, 'error' => 'Missing parameters']);
    }
    exit;
}


// ==========================================================
// Default action: Streaming Chat Logic
// ==========================================================

// Your OpenAI API Key
$apiKey = getenv('OPENAI_API_KEY') ?: '你的Key'; // Replace with your actual key if not using env var

// Get data from client
$clientHistory = json_decode($_GET['history'] ?? '[]', true);
$chatId = $_GET['chatId'] ?? null;

// Find the very last user message to use for title generation
$lastUserMessage = '';
foreach (array_reverse($clientHistory) as $msg) {
    if ($msg['role'] === 'user') {
        $lastUserMessage = $msg['content'];
        break;
    }
}

$isNewChat = !$chatId || $chatId === 'null';
$title = '';

if ($isNewChat) {
    $chatId = 'chat_' . uniqid();
    $title = mb_substr($lastUserMessage, 0, 30);
    
    $metadata = ['chatId' => $chatId, 'title' => $title];
    echo "event: metadata\n";
    echo "data: " . json_encode($metadata) . "\n\n";
    flush();
}

$ch = curl_init('https://api.lhyb.dpdns.org/v1/chat/completions');

$fullResponse = '';

$writeFunction = function($curl, $data) use (&$fullResponse) {
    $fullResponse .= $data;
    
    $lines = explode("\n", $data);
    foreach ($lines as $line) {
        if (strpos($line, 'data: ') === 0) {
            $jsonStr = substr($line, 6);
            if (trim($jsonStr) === '[DONE]') {
                echo "data: [DONE]\n\n";
            } else {
                $decoded = json_decode($jsonStr, true);
                if (isset($decoded['choices'][0]['delta']['content'])) {
                    $delta = $decoded['choices'][0]['delta']['content'];
                    echo "data: " . json_encode(['content' => $delta]) . "\n\n";
                }
            }
        }
    }
    @ob_flush();
    flush();
    return strlen($data);
};

curl_setopt_array($ch, [
    CURLOPT_HTTPHEADER => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ],
    CURLOPT_POST => true,
    CURLOPT_POSTFIELDS => json_encode([
        'model' => '模型名',
        'messages' => $clientHistory,
        'stream' => true,
    ]),
    CURLOPT_RETURNTRANSFER => false,
    CURLOPT_WRITEFUNCTION => $writeFunction,
    CURLOPT_TIMEOUT => 120,
    CURLOPT_SSL_VERIFYPEER => false,
    CURLOPT_SSL_VERIFYHOST => false,
]);

curl_exec($ch);

if (curl_errno($ch)) {
    // error_log("cURL Error: " . curl_error($ch));
}
curl_close($ch);

// After the stream is complete, save the conversation.
// This part will run even if the user has disconnected.
$finalAIReply = '';
$lines = explode("\n", $fullResponse);
foreach ($lines as $line) {
    if (strpos($line, 'data: ') === 0) {
        $jsonStr = substr($line, 6);
        if(trim($jsonStr) !== '' && trim($jsonStr) !== '[DONE]') {
             $decoded = json_decode($jsonStr, true);
             if (isset($decoded['choices'][0]['delta']['content'])) {
                 $finalAIReply .= $decoded['choices'][0]['delta']['content'];
             }
        }
    }
}

if (!empty(trim($finalAIReply))) {
    $allChats = loadChats($historyFile);
    
    $finalHistory = $clientHistory;
    $finalHistory[] = ['role' => 'assistant', 'content' => $finalAIReply];
    
    if (isset($allChats[$chatId])) {
        $allChats[$chatId]['history'] = $finalHistory;
        $allChats[$chatId]['lastUpdated'] = time();
    } else {
        $allChats[$chatId] = [
            'id' => $chatId,
            'title' => $title,
            'history' => $finalHistory,
            'lastUpdated' => time()
        ];
    }
    
    saveChats($historyFile, $allChats);
}
