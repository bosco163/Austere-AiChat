<?php
declare(strict_types=1);

// 强制关闭输出缓冲，确保SSE实时推送
while (@ob_end_clean());

//此处配置API与模型（此Key为公共Key，并非不小心泄露，可以任君使用）
const OPENAI_API_KEY = 'sk-DuJ0PdmJLrABqIVJkEaue1NgQZ4o0mynwv3g2RQQworSczmV';
const OPENAI_BASE_URL = 'https://new-api.koyeb.app/v1';
const MODEL_CONFIG = [
    'chat_default' => 'kimi-k2.5-instant',
    'title_model' => 'kimi-k2-0905',
    'supported' => ['kimi-k2.5-instant','kimi-k2.5', 'gemini-3-flash-preview', 'qwen3.5-397b-a17b', 'qwen3.5-397b-a17b-thinking', 'glm-5-instant', 'glm-5', 'minimax-m2.5', 'minimax-m2.1', 'deepseek-chat-nx', 'deepseek-reasoner-nx']
];
const HISTORY_DIR = __DIR__ . '/history';
const UPLOAD_DIR = __DIR__ . '/uploads';
const STREAM_DIR = __DIR__ . '/streams';
const STOP_DIR = __DIR__ . '/stops';
const MAX_CONTEXT_MESSAGES = 0;
const TITLE_MIN_MESSAGES = 2;
const MAX_ATTACHMENTS_PER_TURN = 6;
const MAX_IMAGE_BYTES = 5000000;
const MAX_UPLOAD_BYTES = 15 * 1024 * 1024;
const STREAM_TOKEN_TTL = 600;
const STOP_TOKEN_TTL = 3600;

if (!is_dir(HISTORY_DIR)) mkdir(HISTORY_DIR, 0777, true);
if (!is_dir(UPLOAD_DIR)) mkdir(UPLOAD_DIR, 0777, true);
if (!is_dir(STREAM_DIR)) mkdir(STREAM_DIR, 0777, true);
if (!is_dir(STOP_DIR)) mkdir(STOP_DIR, 0777, true);

function model_supported(string $m): bool { return in_array($m, MODEL_CONFIG['supported'], true); }
function safe_id(?string $id): ?string { return ($id && preg_match('/^[a-zA-Z0-9_-]{8,64}$/', $id)) ? $id : null; }
function new_chat_id(): string { return 'chat_' . bin2hex(random_bytes(8)); }
function chat_file(string $id): string { return HISTORY_DIR . '/' . $id . '.json'; }
function stream_file(string $token): string { return STREAM_DIR . '/' . $token . '.json'; }
function new_stream_token(): string { return 'st_' . bin2hex(random_bytes(16)); }
function new_stop_token(): string { return 'stop_' . bin2hex(random_bytes(16)); }
function stop_file(string $token): string { return STOP_DIR . '/' . $token . '.json'; }

function load_chat(string $id): ?array {
    $f = chat_file($id);
    if (!is_file($f)) return null;
    $raw = file_get_contents($f);
    if ($raw === false) return null;
    $j = json_decode($raw, true);
    return is_array($j) ? $j : null;
}
function save_chat(array $chat): bool {
    $chat['updated_at'] = time();
    if (!isset($chat['pinned'])) $chat['pinned'] = false;
    if (!isset($chat['order_index'])) $chat['order_index'] = 0;
    if (!isset($chat['title_locked'])) $chat['title_locked'] = false;
    $f = chat_file($chat['id']);
    $tmp = $f . '.tmp';
    $ok = file_put_contents($tmp, json_encode($chat, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT));
    if ($ok === false) return false;
    return rename($tmp, $f);
}
function json_out(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function sse_out(array $data): void {
    echo 'data: ' . json_encode($data, JSON_UNESCAPED_UNICODE) . "\n\n";
    if (ob_get_level() > 0) ob_flush();
    flush();
}
function post_json(string $url, array $body, int $timeout = 120): array {
    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => $url,
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_API_KEY],
        CURLOPT_POSTFIELDS => json_encode($body, JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT => $timeout
    ]);
    $resp = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);
    return ['ok' => $resp !== false && $code < 400, 'code' => $code, 'err' => $err, 'body' => $resp ?: ''];
}
function clamp_title(string $t): string {
    $t = trim(preg_replace('/\s+/u', ' ', $t));
    $t = preg_replace('/[""\'`]/u', '', $t ?? '');
    if ($t === '') $t = '新会话';
    if (mb_strlen($t) > 30) $t = mb_substr($t, 0, 30);
    return $t;
}
function sanitize_filename(string $name): string {
    $name = preg_replace('/[^\w.\-\x{4e00}-\x{9fa5}]+/u', '_', $name);
    $name = trim($name, '._ ');
    return $name !== '' ? $name : 'file.bin';
}
function generate_title_by_ai(array $messages): string {
    if (count($messages) < TITLE_MIN_MESSAGES) return '新会话';
    $sample = [];
    foreach ($messages as $m) {
        $sample[] = ['role' => $m['role'] ?? 'user', 'content' => mb_substr((string)($m['content'] ?? ''), 0, 300)];
        if (count($sample) >= 6) break;
    }
    $res = post_json(OPENAI_BASE_URL . '/chat/completions', [
        'model' => MODEL_CONFIG['title_model'],
        'messages' => [
            ['role' => 'system', 'content' => '你是标题生成器。'],
            ['role' => 'user', 'content' => "根据对话生成一个简洁的标题（8-18字），仅输出标题。\n\n" . json_encode($sample, JSON_UNESCAPED_UNICODE)]
        ],
        'temperature' => 0.2
    ], 30);
    if (!$res['ok']) return '新会话';
    $j = json_decode($res['body'], true);
    return clamp_title((string)($j['choices'][0]['message']['content'] ?? '新会话'));
}
function get_mime_type($filepath) {
    if (function_exists('finfo_open')) {
        $finfo = finfo_open(FILEINFO_MIME_TYPE);
        if ($finfo) {
            $mime = finfo_file($finfo, $filepath);
            finfo_close($finfo);
            if ($mime) return $mime;
        }
    }
    if (function_exists('mime_content_type')) {
        $mime = mime_content_type($filepath);
        if ($mime) return $mime;
    }
    $ext = strtolower(pathinfo($filepath, PATHINFO_EXTENSION));
    $map = [
        'txt' => 'text/plain', 'log' => 'text/plain', 'md' => 'text/markdown',
        'json' => 'application/json', 'xml' => 'application/xml', 'yaml' => 'application/x-yaml', 'yml' => 'application/x-yaml',
        'csv' => 'text/csv', 'html' => 'text/html', 'htm' => 'text/html', 'css' => 'text/css', 'js' => 'application/javascript',
        'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg', 'png' => 'image/png', 'gif' => 'image/gif', 'webp' => 'image/webp', 'svg' => 'image/svg+xml',
        'pdf' => 'application/pdf',
        'doc' => 'application/msword', 'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'xls' => 'application/vnd.ms-excel', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        'zip' => 'application/zip', 'rar' => 'application/x-rar-compressed',
        'mp3' => 'audio/mpeg', 'mp4' => 'video/mp4',
    ];
    return $map[$ext] ?? 'application/octet-stream';
}
function delete_chat_attachments(array $chat): void {
    $messages = $chat['messages'] ?? [];
    foreach ($messages as $m) {
        $atts = $m['attachments'] ?? [];
        if (!is_array($atts)) continue;
        foreach ($atts as $a) {
            $storedName = $a['stored_name'] ?? '';
            if ($storedName) {
                $path = UPLOAD_DIR . '/' . basename($storedName);
                if (is_file($path)) @unlink($path);
            }
        }
    }
}
function cleanup_stream_tokens(): void {
    $files = glob(STREAM_DIR . '/*.json') ?: [];
    $now = time();
    foreach ($files as $f) {
        $raw = @file_get_contents($f);
        if ($raw === false) continue;
        $j = json_decode($raw, true);
        $created = (int)($j['created_at'] ?? 0);
        $used = (bool)($j['used'] ?? false);
        if (($created > 0 && $now - $created > STREAM_TOKEN_TTL) || $used) {
            @unlink($f);
        }
    }
}
function cleanup_stop_tokens(): void {
    $files = glob(STOP_DIR . '/*.json') ?: [];
    $now = time();
    foreach ($files as $f) {
        $raw = @file_get_contents($f);
        if ($raw === false) continue;
        $j = json_decode($raw, true);
        $created = (int)($j['created_at'] ?? 0);
        if ($created <= 0 || $now - $created > STOP_TOKEN_TTL) {
            @unlink($f);
        }
    }
}
function create_stop_token(): string {
    cleanup_stop_tokens();
    $token = new_stop_token();
    $data = [
        'created_at' => time(),
        'stopped' => false
    ];
    file_put_contents(stop_file($token), json_encode($data, JSON_UNESCAPED_UNICODE));
    return $token;
}
function mark_stop_token(string $token): bool {
    if (!preg_match('/^stop_[a-zA-Z0-9]{32}$/', $token)) return false;
    $f = stop_file($token);
    if (!is_file($f)) return false;
    $raw = file_get_contents($f);
    if ($raw === false) return false;
    $j = json_decode($raw, true);
    if (!is_array($j)) return false;
    $j['stopped'] = true;
    $j['stopped_at'] = time();
    return file_put_contents($f, json_encode($j, JSON_UNESCAPED_UNICODE)) !== false;
}
function is_stop_requested(string $token): bool {
    if (!preg_match('/^stop_[a-zA-Z0-9]{32}$/', $token)) return false;
    $f = stop_file($token);
    if (!is_file($f)) return false;
    $raw = @file_get_contents($f);
    if ($raw === false) return false;
    $j = json_decode($raw, true);
    return is_array($j) && !empty($j['stopped']);
}
function delete_stop_token(string $token): void {
    if (!preg_match('/^stop_[a-zA-Z0-9]{32}$/', $token)) return;
    $f = stop_file($token);
    if (is_file($f)) @unlink($f);
}
function create_stream_payload(array $payload): string {
    cleanup_stream_tokens();
    $token = new_stream_token();
    $data = [
        'created_at' => time(),
        'used' => false,
        'payload' => $payload
    ];
    file_put_contents(stream_file($token), json_encode($data, JSON_UNESCAPED_UNICODE));
    return $token;
}
function consume_stream_payload(string $token): ?array {
    if (!preg_match('/^st_[a-zA-Z0-9]{32}$/', $token)) return null;
    $f = stream_file($token);
    if (!is_file($f)) return null;
    $raw = file_get_contents($f);
    if ($raw === false) return null;
    $j = json_decode($raw, true);
    if (!is_array($j)) { @unlink($f); return null; }
    $created = (int)($j['created_at'] ?? 0);
    if ($created <= 0 || time() - $created > STREAM_TOKEN_TTL) { @unlink($f); return null; }
    $payload = $j['payload'] ?? null;
    @unlink($f);
    return is_array($payload) ? $payload : null;
}

$action = $_GET['action'] ?? '';

if ($action === 'models') json_out(['ok' => true, 'models' => MODEL_CONFIG['supported'], 'default' => MODEL_CONFIG['chat_default']]);

if ($action === 'stop_chat') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $stopToken = (string)($b['stop_token'] ?? '');
    if ($stopToken === '') json_out(['ok' => false, 'error' => 'Missing stop token'], 400);
    $ok = mark_stop_token($stopToken);
    json_out(['ok' => $ok]);
}

if ($action === 'upload') {
    if (!isset($_FILES['file']) || !is_array($_FILES['file'])) json_out(['ok' => false, 'error' => 'No file'], 400);
    $f = $_FILES['file'];
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) json_out(['ok' => false, 'error' => 'Upload failed'], 400);
    $size = (int)($f['size'] ?? 0);
    if ($size <= 0 || $size > MAX_UPLOAD_BYTES) json_out(['ok' => false, 'error' => '文件太大，最大限制15MB'], 400);

    $tmp = (string)($f['tmp_name'] ?? '');
    if ($tmp === '' || !is_uploaded_file($tmp)) json_out(['ok' => false, 'error' => 'Invalid upload'], 400);

    $rawName = (string)($f['name'] ?? 'file.bin');
    $safeName = sanitize_filename($rawName);
    $ext = pathinfo($safeName, PATHINFO_EXTENSION);
    $token = bin2hex(random_bytes(10));
    $stored = $token . ($ext !== '' ? ('.' . $ext) : '');
    $dest = UPLOAD_DIR . '/' . $stored;

    if (!move_uploaded_file($tmp, $dest)) json_out(['ok' => false, 'error' => '保存失败'], 500);

    $mime = (string)($f['type'] ?? 'application/octet-stream');
    $isImage = strpos($mime, 'image/') === 0;
    $url = '?action=file&name=' . rawurlencode($stored);

    json_out([
        'ok' => true,
        'file' => [
            'name' => $safeName,
            'stored_name' => $stored,
            'mime' => $mime,
            'size' => filesize($dest) ?: $size,
            'is_image' => $isImage,
            'url' => $url
        ]
    ]);
}

if ($action === 'delete_file') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $name = basename((string)($b['name'] ?? ''));
    if ($name === '' || !preg_match('/^[a-zA-Z0-9._-]{6,120}$/', $name)) {
        json_out(['ok' => false, 'error' => 'Invalid name'], 400);
    }
    $path = UPLOAD_DIR . '/' . $name;
    if (is_file($path)) {
        @unlink($path);
    }
    json_out(['ok' => true]);
}

if ($action === 'file') {
    $name = basename((string)($_GET['name'] ?? ''));
    if ($name === '' || !preg_match('/^[a-zA-Z0-9._-]{6,120}$/', $name)) {
        http_response_code(404); exit;
    }
    $path = UPLOAD_DIR . '/' . $name;
    if (!is_file($path)) { http_response_code(404); exit; }

    $mime = get_mime_type($path);
    header('Content-Type: ' . ($mime ?: 'application/octet-stream'));
    header('Content-Length: ' . filesize($path));
    header('Content-Disposition: inline; filename="' . $name . '"');
    readfile($path);
    exit;
}

if ($action === 'list') {
    $files = glob(HISTORY_DIR . '/*.json') ?: [];
    $items = [];
    foreach ($files as $f) {
        $raw = file_get_contents($f);
        if ($raw === false) continue;
        $c = json_decode($raw, true);
        if (!is_array($c)) continue;
        $items[] = [
            'id' => $c['id'] ?? basename($f, '.json'),
            'title' => $c['title'] ?? '无标题',
            'updated_at' => (int)($c['updated_at'] ?? filemtime($f) ?: time()),
            'pinned' => (bool)($c['pinned'] ?? false),
            'order_index' => (int)($c['order_index'] ?? 0),
            'title_locked' => (bool)($c['title_locked'] ?? false),
        ];
    }
    usort($items, function($a, $b){
        if (($a['pinned'] ?? false) !== ($b['pinned'] ?? false)) return ($b['pinned'] <=> $a['pinned']);
        if (($a['order_index'] ?? 0) !== ($b['order_index'] ?? 0)) return ($a['order_index'] <=> $b['order_index']);
        return ($b['updated_at'] <=> $a['updated_at']);
    });
    json_out(['ok' => true, 'items' => $items]);
}

if ($action === 'reorder') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $ids = $b['ids'] ?? [];
    if (!is_array($ids)) json_out(['ok' => false, 'error' => 'Invalid ids'], 400);
    $i = 0;
    foreach ($ids as $id0) {
        $id = safe_id((string)$id0);
        if (!$id) continue;
        $chat = load_chat($id);
        if (!$chat) continue;
        $chat['order_index'] = $i++;
        save_chat($chat);
    }
    json_out(['ok' => true]);
}

if ($action === 'get') {
    $id = safe_id($_GET['id'] ?? null);
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);
    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);
    if (!isset($chat['pinned'])) $chat['pinned'] = false;
    if (!isset($chat['order_index'])) $chat['order_index'] = 0;
    if (!isset($chat['title_locked'])) $chat['title_locked'] = false;
    json_out(['ok' => true, 'chat' => $chat]);
}

if ($action === 'delete') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);

    $chat = load_chat($id);
    if ($chat) delete_chat_attachments($chat);

    $f = chat_file($id);
    if (is_file($f)) @unlink($f);
    json_out(['ok' => true]);
}

if ($action === 'clone') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);

    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);

    $newChat = $chat;
    $newChat['id'] = new_chat_id();
    $newChat['title'] = ($chat['title'] ?? '新会话') . ' (副本)';
    $newChat['created_at'] = time();
    $newChat['updated_at'] = time();
    $newChat['pinned'] = false;
    $newChat['order_index'] = 0;
    $newChat['title_locked'] = false;

    if (save_chat($newChat)) json_out(['ok' => true, 'new_id' => $newChat['id']]);
    json_out(['ok' => false, 'error' => 'Save failed'], 500);
}

if ($action === 'bulk_delete') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $ids = $b['ids'] ?? [];
    if (!is_array($ids)) json_out(['ok' => false, 'error' => 'Invalid ids'], 400);
    $n = 0;
    foreach ($ids as $id0) {
        $id = safe_id((string)$id0);
        if (!$id) continue;
        $chat = load_chat($id);
        if ($chat) delete_chat_attachments($chat);
        $f = chat_file($id);
        if (is_file($f) && @unlink($f)) $n++;
    }
    json_out(['ok' => true, 'deleted' => $n]);
}

if ($action === 'bulk_pin') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $ids = $b['ids'] ?? [];
    $pin = (bool)($b['pin'] ?? true);
    if (!is_array($ids)) json_out(['ok' => false, 'error' => 'Invalid ids'], 400);
    $n = 0;
    foreach ($ids as $id0) {
        $id = safe_id((string)$id0);
        if (!$id) continue;
        $chat = load_chat($id);
        if (!$chat) continue;
        $chat['pinned'] = $pin;
        if (save_chat($chat)) $n++;
    }
    json_out(['ok' => true, 'updated' => $n]);
}

if ($action === 'rename') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    $title = clamp_title((string)($b['title'] ?? ''));
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);
    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);
    $chat['title'] = $title;
    save_chat($chat);
    json_out(['ok' => true, 'title' => $title]);
}

if ($action === 'toggle_lock') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);
    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);
    $chat['title_locked'] = !($chat['title_locked'] ?? false);
    save_chat($chat);
    json_out(['ok' => true, 'locked' => $chat['title_locked']]);
}

if ($action === 'update_messages') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    $messages = $b['messages'] ?? null;
    if (!$id || !is_array($messages)) json_out(['ok' => false, 'error' => 'Invalid payload'], 400);
    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);

    $norm = [];
    foreach ($messages as $m) {
        $r = (string)($m['role'] ?? '');
        $c = (string)($m['content'] ?? '');
        $model = (string)($m['model'] ?? '');
        if (!in_array($r, ['user', 'assistant', 'system'], true)) continue;
        $x = ['role' => $r, 'content' => $c];

        if ($r === 'assistant') {
            $x['model'] = $model !== '' ? $model : ($chat['model'] ?? MODEL_CONFIG['chat_default']);
            if (isset($m['reasoning_content'])) $x['reasoning_content'] = (string)$m['reasoning_content'];
        }
        if ($r === 'user' && isset($m['attachments']) && is_array($m['attachments'])) {
            $atts = [];
            foreach ($m['attachments'] as $a) {
                if (!is_array($a)) continue;
                $atts[] = [
                    'name' => (string)($a['name'] ?? 'file'),
                    'mime' => (string)($a['mime'] ?? 'application/octet-stream'),
                    'size' => (int)($a['size'] ?? 0),
                    'stored_name' => (string)($a['stored_name'] ?? ''),
                    'url' => (string)($a['url'] ?? ''),
                    'is_image' => (bool)($a['is_image'] ?? false),
                ];
            }
            $x['attachments'] = $atts;
        }
        $norm[] = $x;
    }
    $chat['messages'] = $norm;
    save_chat($chat);
    json_out(['ok' => true]);
}

if ($action === 'title_ai') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    $id = safe_id($b['id'] ?? null);
    if (!$id) json_out(['ok' => false, 'error' => 'Invalid id'], 400);
    $chat = load_chat($id);
    if (!$chat) json_out(['ok' => false, 'error' => 'Not found'], 404);

    if (($chat['title_locked'] ?? false) === true) {
        json_out([
            'ok' => true,
            'title' => (string)($chat['title'] ?? '新会话'),
            'locked' => true,
            'skipped' => true
        ]);
    }

    $title = generate_title_by_ai($chat['messages'] ?? []);
    $chat['title'] = $title;
    save_chat($chat);
    json_out(['ok' => true, 'title' => $title]);
}

if ($action === 'chat_prepare') {
    $b = json_decode(file_get_contents('php://input') ?: '', true);
    if (!is_array($b)) json_out(['ok' => false, 'error' => 'Invalid payload'], 400);

    $id = safe_id($b['id'] ?? null);
    $model = (string)($b['model'] ?? MODEL_CONFIG['chat_default']);
    $msg = trim((string)($b['message'] ?? ''));
    $attachments = $b['attachments'] ?? [];

    if ($msg === '') json_out(['ok' => false, 'error' => 'Empty message'], 400);
    if (!model_supported($model)) json_out(['ok' => false, 'error' => 'Model not allowed'], 400);
    if (!is_array($attachments)) $attachments = [];
    $attachments = array_slice($attachments, 0, MAX_ATTACHMENTS_PER_TURN);

    $stopToken = create_stop_token();
    $token = create_stream_payload([
        'id' => $id,
        'model' => $model,
        'message' => $msg,
        'attachments' => $attachments,
        'stop_token' => $stopToken
    ]);
    json_out(['ok' => true, 'token' => $token, 'stop_token' => $stopToken]);
}

if ($action === 'chat') {
    ignore_user_abort(false);
    set_time_limit(0);

    header('Content-Type: text/event-stream; charset=utf-8');
    header('Cache-Control: no-cache, no-transform');
    header('Connection: keep-alive');
    header('X-Accel-Buffering: no');

    $token = (string)($_GET['token'] ?? '');
    $payload = consume_stream_payload($token);
    if (!is_array($payload)) { sse_out(['type' => 'error', 'message' => 'Invalid or expired stream token']); exit; }

    $id = safe_id($payload['id'] ?? null);
    $model = (string)($payload['model'] ?? MODEL_CONFIG['chat_default']);
    $msg = trim((string)($payload['message'] ?? ''));
    $attachments = $payload['attachments'] ?? [];
    $stopToken = (string)($payload['stop_token'] ?? '');

    if ($msg === '') { sse_out(['type' => 'error', 'message' => 'Empty message']); exit; }
    if (!model_supported($model)) { sse_out(['type' => 'error', 'message' => 'Model not allowed']); exit; }

    if (!is_array($attachments)) $attachments = [];
    $attachments = array_slice($attachments, 0, MAX_ATTACHMENTS_PER_TURN);

    $chat = $id ? load_chat($id) : null;
    if (!$chat) {
        $id = $id ?: new_chat_id();
        $chat = [
            'id' => $id, 'title' => '新会话', 'model' => $model, 'messages' => [],
            'pinned' => false, 'order_index' => 0, 'created_at' => time(), 'updated_at' => time(),
            'title_locked' => false
        ];
    }

    $normAttachments = [];
    foreach ($attachments as $a) {
        if (!is_array($a)) continue;
        $normAttachments[] = [
            'name' => (string)($a['name'] ?? 'file'),
            'mime' => (string)($a['mime'] ?? 'application/octet-stream'),
            'size' => (int)($a['size'] ?? 0),
            'stored_name' => (string)($a['stored_name'] ?? ''),
            'url' => (string)($a['url'] ?? ''),
            'is_image' => (bool)($a['is_image'] ?? false),
        ];
    }

    $chat['model'] = $model;
    $chat['messages'][] = ['role' => 'user', 'content' => $msg, 'attachments' => $normAttachments];
    save_chat($chat);

    sse_out(['type' => 'meta', 'id' => $chat['id'], 'title' => $chat['title'], 'stop_token' => $stopToken]);

    $ctx = $chat['messages'];
    if (MAX_CONTEXT_MESSAGES > 0 && count($ctx) > MAX_CONTEXT_MESSAGES) $ctx = array_slice($ctx, -MAX_CONTEXT_MESSAGES);

    $apiMessages = [[
        'role' => 'system',
        'content' => ""
    ]];

    foreach ($ctx as $m) {
        $role = (string)($m['role'] ?? 'user');
        $text = (string)($m['content'] ?? '');

        if ($role === 'user') {
            $contentParts = [['type' => 'text', 'text' => $text]];
            $atts = $m['attachments'] ?? [];
            $textAttachmentLines = [];

            if (is_array($atts)) {
                foreach ($atts as $a) {
                    $mime = (string)($a['mime'] ?? '');
                    $name = (string)($a['name'] ?? 'file');
                    $storedName = (string)($a['stored_name'] ?? '');
                    $path = $storedName !== '' ? (UPLOAD_DIR . '/' . basename($storedName)) : '';

                    if ($storedName !== '' && is_file($path) && strpos($mime, 'image/') === 0) {
                        $bin = file_get_contents($path);
                        if ($bin !== false) {
                            $approxBytes = strlen($bin);
                            if ($approxBytes <= MAX_IMAGE_BYTES) {
                                $b64 = base64_encode($bin);
                                $contentParts[] = [
                                    'type' => 'image_url',
                                    'image_url' => ['url' => 'data:' . $mime . ';base64,' . $b64]
                                ];
                                continue;
                            }
                        }
                    }

                    if ($storedName !== '' && is_file($path)) {
                        $snippet = '';
                        if (preg_match('/^(text\/|application\/json|application\/xml|application\/x-yaml|application\/javascript)/i', $mime) || preg_match('/\.(txt|md|csv|json|xml|yaml|yml|log|ini|conf|js|ts|py|java|php|go|rs|sql)$/i', $name)) {
                            $raw = file_get_contents($path);
                            if ($raw !== false) $snippet = mb_substr((string)$raw, 0, 2000);
                        }
                        $line = '- 文件: ' . $name . ' (' . $mime . ', ' . ((int)filesize($path)) . " bytes)";
                        if ($snippet !== '') $line .= "\n  内容摘要: " . preg_replace('/\s+/u', ' ', $snippet);
                        $textAttachmentLines[] = $line;
                    } else {
                        $textAttachmentLines[] = '- 文件: ' . $name . ' (' . $mime . ')';
                    }
                }
            }

            if ($textAttachmentLines) {
                $contentParts[] = [
                    'type' => 'text',
                    'text' => "以下是用户上传文件信息，请结合它们回答：\n" . implode("\n", $textAttachmentLines)
                ];
            }

            $apiMessages[] = ['role' => 'user', 'content' => $contentParts];
        } else {
            $apiMessages[] = ['role' => $role, 'content' => $text];
        }
    }

    $assistant = '';
    $reasoning = '';
    $buffer = '';
    $upstreamSnippet = '';
    $isReasoningPhase = false;
    $stopRequested = false;

    $ch = curl_init();
    curl_setopt_array($ch, [
        CURLOPT_URL => OPENAI_BASE_URL . '/chat/completions',
        CURLOPT_POST => true,
        CURLOPT_HTTPHEADER => ['Content-Type: application/json', 'Authorization: Bearer ' . OPENAI_API_KEY],
        CURLOPT_POSTFIELDS => json_encode([
            'model' => $model,
            'messages' => $apiMessages,
            'stream' => true,
            'temperature' => 0.7
        ], JSON_UNESCAPED_UNICODE),
        CURLOPT_RETURNTRANSFER => false,
        CURLOPT_TIMEOUT => 0
    ]);

    curl_setopt($ch, CURLOPT_WRITEFUNCTION, function($ch, $chunk) use (&$assistant, &$reasoning, &$buffer, &$upstreamSnippet, &$isReasoningPhase, &$stopRequested, $stopToken) {
        if (connection_aborted()) {
            $stopRequested = true;
            return 0;
        }

        if ($stopToken !== '' && is_stop_requested($stopToken)) {
            $stopRequested = true;
            return 0;
        }

        if (strlen($upstreamSnippet) < 600) $upstreamSnippet .= $chunk;
        $buffer .= $chunk;

        while (($pos = strpos($buffer, "\n")) !== false) {
            $line = trim(substr($buffer, 0, $pos));
            $buffer = substr($buffer, $pos + 1);
            if ($line === '' || strpos($line, 'data:') !== 0) continue;
            $data = trim(substr($line, 5));
            if ($data === '[DONE]') continue;
            $j = json_decode($data, true);
            if (!is_array($j)) continue;

            $delta = $j['choices'][0]['delta'] ?? [];

            $reasoningDelta = (string)($delta['reasoning_content'] ?? '');
            if ($reasoningDelta !== '') {
                if (!$isReasoningPhase) {
                    $isReasoningPhase = true;
                    sse_out(['type' => 'reasoning_start']);
                }
                $reasoning .= $reasoningDelta;
                sse_out(['type' => 'reasoning_delta', 'text' => $reasoningDelta]);
            }

            $contentDelta = (string)($delta['content'] ?? '');
            if ($contentDelta !== '') {
                if ($isReasoningPhase) {
                    $isReasoningPhase = false;
                    sse_out(['type' => 'reasoning_end']);
                }
                $assistant .= $contentDelta;
                sse_out(['type' => 'delta', 'text' => $contentDelta]);
            }

            if ($stopToken !== '' && is_stop_requested($stopToken)) {
                $stopRequested = true;
                return 0;
            }
        }

        return strlen($chunk);
    });

    $ok = curl_exec($ch);
    $err = curl_error($ch);
    $code = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
    curl_close($ch);

    $shouldSavePartial = ($assistant !== '' || $reasoning !== '');

    if ($stopRequested) {
        if ($shouldSavePartial) {
            $assistantMsg = ['role' => 'assistant', 'content' => $assistant, 'model' => $model];
            if ($reasoning !== '') $assistantMsg['reasoning_content'] = $reasoning;
            $chat['messages'][] = $assistantMsg;
            save_chat($chat);
        } else {
            save_chat($chat);
        }
        sse_out(['type' => 'stopped', 'id' => $chat['id'], 'title' => $chat['title'], 'model' => $model]);
        delete_stop_token($stopToken);
        exit;
    }

    if ($ok === false || $code >= 400) {
        $detail = $err ?: ('HTTP ' . $code);
        $snippet = trim(mb_substr($upstreamSnippet, 0, 240));
        if ($snippet !== '') $detail .= ' | ' . $snippet;

        if ($shouldSavePartial) {
            $assistantMsg = ['role' => 'assistant', 'content' => $assistant, 'model' => $model];
            if ($reasoning !== '') $assistantMsg['reasoning_content'] = $reasoning;
            $chat['messages'][] = $assistantMsg;
        }
        save_chat($chat);
        sse_out(['type' => 'error', 'message' => 'Upstream error: ' . $detail, 'partial_saved' => $shouldSavePartial]);
        delete_stop_token($stopToken);
        exit;
    }

    $assistantMsg = ['role' => 'assistant', 'content' => $assistant, 'model' => $model];
    if ($reasoning !== '') $assistantMsg['reasoning_content'] = $reasoning;
    $chat['messages'][] = $assistantMsg;

    $isLocked = $chat['title_locked'] ?? false;
    if (!$isLocked) {
        $oldTitle = $chat['title'];
        $tempTitle = generate_title_by_ai($chat['messages']);
        if ($tempTitle !== '新会话') $chat['title'] = $tempTitle;
        else $chat['title'] = ($oldTitle === '新会话') ? $tempTitle : $oldTitle;
        save_chat($chat);
        sse_out(['type' => 'title_updated', 'title' => $chat['title']]);
    } else {
        save_chat($chat);
    }

    sse_out(['type' => 'done', 'id' => $chat['id'], 'title' => $chat['title'], 'model' => $model]);
    delete_stop_token($stopToken);
    exit;
}
?>
<!doctype html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8" />
<meta content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0,viewport-fit=cover" name="viewport" />
<title>Austere AiChat（已开源）</title>
<script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
<script>
window.MathJax = {
  tex:{inlineMath:[['$','$']],displayMath:[['$$','$$']]},
  svg:{fontCache:'global'}
};
</script>
<script src="https://cdn.jsdelivr.net/npm/mathjax@3/es5/tex-svg.js"></script>
<script src="https://cdn.jsdelivr.net/npm/mermaid@10/dist/mermaid.min.js"></script>
<script>
mermaid.initialize({ startOnLoad:false, securityLevel:'loose', theme:'default' });
</script>
<style>
*{box-sizing:border-box}
body{
  margin:0;
  font-family:-apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;
  background:#fff;
  color:#111
}
.app{display:flex;height:100vh;background:#fff}
.side{
  width:300px;
  background:#fafafa;
  border-right:1px solid #ddd;
  display:flex;
  flex-direction:column;
  transition:transform .2s ease, width .2s ease
}
.side-top{padding:10px;border-bottom:1px solid #ddd;display:grid;grid-template-columns:1fr;gap:6px}
.side-actions{padding:8px;border-bottom:1px solid #ddd;display:flex;gap:6px;flex-wrap:wrap;align-items:center}
.history{padding:10px;overflow:auto;flex:1}
.item{
  border:1px solid #ddd;
  border-radius:10px;
  padding:8px;
  margin-bottom:8px;
  background:#fff;
  cursor:pointer;
  position:relative
}
.item.active{border-color:#111;background:#f3f3f3}
.item.dragging{opacity:.5}
.item.drag-over{border-color:#111;background:#f5f5f5}
.item-top{display:flex;align-items:center;gap:6px}
.item-title{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;user-select:none}
.item-hit{
  font-size:12px;
  color:#222;
  background:#f5f5f5;
  border:1px solid #ddd;
  border-radius:8px;
  padding:6px 8px;
  margin-top:6px;
  line-height:1.45;
  cursor:pointer
}
.item-hit mark{background:#111;color:#fff;border-radius:3px;padding:0 2px}
.item-meta{font-size:12px;color:#666;margin-top:6px}
.item-ops{display:flex;gap:4px;margin-top:6px}
.expand-hits{font-size:12px;color:#333;cursor:pointer;margin-top:4px}
.hidden-hits{display:none}
.hidden-hits.show{display:block}
mark.hl{background:#111;color:#fff;border-radius:3px;padding:0 2px}
.overview-item-content mark,
.overview-item-content mark.hl{
  background:#111;
  color:#fff;
  border-radius:3px;
  padding:0 2px;
}
.lock-btn{
  padding:1px 4px;
  font-size:10px;
  background:transparent;
  border:1px solid transparent;
  cursor:pointer;
  opacity:0.45;
  color:#666;
  display:flex;
  align-items:center;
  border-radius:4px;
  flex-shrink:0;
}
.lock-btn:hover{opacity:1;background:#f0f0f0}
.lock-btn.locked{opacity:1;color:#111;border-color:#111;background:#f3f3f3}
.main{flex:1;display:flex;flex-direction:column;min-width:0}
.top{
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:10px;
  padding:10px 14px;
  background:#fff;
  border-bottom:1px solid #ddd
}
.title{margin:0;font-size:18px;cursor:pointer}
.hint{font-size:12px;color:#666}
.msgs{flex:1;overflow:auto;padding:12px}
.msg{max-width:900px;margin:0 auto 10px auto;padding:10px;overflow:hidden}
.msg.user{
  background:#f7f7f7;
  border:1px solid #ddd;
  border-radius:12px
}
.msg.assistant{background:transparent;border:none;border-radius:0;padding-left:10px;padding-right:10px}
.msg-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:6px;gap:8px}
.msg .msg-header:empty{display:none;margin:0}
.role{font-size:12px;color:#666;display:block}
.reasoning-btn{
  font-size:11px;
  color:#111;
  background:#f2f2f2;
  border:1px solid #ccc;
  border-radius:4px;
  padding:2px 8px;
  cursor:pointer;
  transition:all .2s
}
.reasoning-btn:hover{background:#e9e9e9}
.reasoning-btn.thinking{
  color:#111;
  background:#eaeaea;
  border-color:#999;
  animation:pulse 1.5s infinite
}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.6}}
.msg-content{line-height:1.65;min-width:0}
.msg-actions{display:flex;justify-content:flex-end;gap:6px;margin-top:8px}
.composer{padding:10px 14px;background:#fff;border-top:1px solid #ddd}
.composer-inner{max-width:900px;margin:0 auto}
.app.wide-mode .msg,
.app.wide-mode .composer-inner{
  max-width:min(1600px,96vw);
}
textarea{
  width:100%;
  border:1px solid #ccc;
  border-radius:10px;
  padding:10px;
  resize:vertical;
  outline:none;
  background:#fff;
  color:#111
}
textarea:focus{border-color:#111}
#input{transition:border-color .15s ease, background .15s ease, box-shadow .15s ease}
#input.dragover{
  border-color:#111;
  background:#f5f5f5;
  box-shadow:0 0 0 3px rgba(0,0,0,.08)
}
.row{display:flex;gap:8px;justify-content:space-between;margin-top:8px;align-items:center}
.btn{
  border:1px solid #ccc;
  background:#fff;
  color:#111;
  border-radius:8px;
  padding:4px 8px;
  cursor:pointer;
  font-size:12px
}
.btn.primary{background:#111;color:#fff;border-color:#111}
.btn.warn{background:#444;color:#fff;border-color:#444}
.btn.danger{background:#111;color:#fff;border-color:#111}
.iconbtn{padding:2px 6px;font-size:11px;background:#fff;border-color:#ccc;color:#333}
.mobile-toggle{display:inline-block}
.badge{font-size:11px;color:#fff;background:#111;border:1px solid #111;border-radius:999px;padding:1px 6px}
.attach-list{display:flex;gap:6px;flex-wrap:wrap}
.attach-chip{
  border:1px solid #ccc;
  background:#fff;
  color:#111;
  border-radius:999px;
  padding:2px 8px;
  font-size:12px;
  display:flex;
  align-items:center;
  gap:6px
}
.attach-link{color:#111;text-decoration:none}
.attach-link:hover{text-decoration:underline}
.attach-x{cursor:pointer;color:#111;font-weight:bold}
.search-input{
  flex:1;
  min-width:120px;
  display:none;
  border:1px solid #ccc;
  border-radius:8px;
  padding:4px 8px;
  font-size:12px;
  background:#fff;
  color:#111
}

@media (min-width: 861px) {
  .app.sidebar-closed .side {
    width: 0;
    min-width: 0;
    border: none;
    overflow: hidden;
  }
}
@media (max-width:860px){
  .side{position:fixed;left:0;top:0;bottom:0;z-index:20;transform:translateX(-100%);box-shadow:0 10px 30px rgba(0,0,0,.12)}
  .side.open{transform:translateX(0)}
  .backdrop{position:fixed;inset:0;background:rgba(0,0,0,.18);z-index:10;display:none}
  .backdrop.show{display:block}
}

.md{min-width:0}
.md p,.md li,.md blockquote,.md h1,.md h2,.md h3,.md h4,.md h5,.md h6,.md th,.md td,.md div{overflow-wrap:anywhere;word-break:break-word}
.md pre{background:#f5f5f5;padding:10px;border-radius:8px;overflow:auto;max-width:100%}
.md code{background:#f5f5f5;padding:2px 4px;border-radius:4px;overflow-wrap:anywhere;word-break:break-word}
.md pre code{background:transparent;padding:0;border-radius:0;white-space:pre;word-break:normal;overflow-wrap:normal}
.md table{border-collapse:collapse;width:max-content;min-width:100%;margin:8px 0;font-size:14px}
.md th,.md td{border:1px solid #ddd;padding:6px 10px;text-align:left;vertical-align:top}
.md th{background:#f3f3f3}
.md ul,.md ol{padding-left:0;margin:0;list-style-position:inside}
.md ul ul,.md ul ol,.md ol ul,.md ol ol{padding-left:20px}
.md blockquote{
  margin:8px 0;
  padding:8px 12px;
  border-left:4px solid #111;
  background:#f8f8f8;
  color:#333
}

.x-scroll{
  overflow-x:auto;
  overflow-y:hidden;
  max-width:100%;
  -webkit-overflow-scrolling:touch;
}
.x-scroll > *{
  min-width:max-content;
}
.x-scroll.code-wrap > pre{
  margin:0;
}
.x-scroll.table-wrap table{
  min-width:max-content;
}
.x-scroll.mj-wrap mjx-container,
.x-scroll.mj-wrap svg{
  max-width:none !important;
}
.x-scroll::-webkit-scrollbar{height:8px}
.x-scroll::-webkit-scrollbar-thumb{background:#bbb;border-radius:999px}
.x-scroll::-webkit-scrollbar-track{background:transparent}

.modal-mask{position:fixed;inset:0;background:rgba(0,0,0,.22);display:none;align-items:center;justify-content:center;z-index:99}
.modal{
  width:min(680px,92vw);
  background:#fff;
  border-radius:12px;
  border:1px solid #ddd;
  padding:12px;
  max-height:85vh;
  display:flex;
  flex-direction:column
}
.modal h3{margin:0 0 10px 0;font-size:16px}
.modal textarea{min-height:180px;width:100%;resize:vertical}
.modal .ops{display:flex;justify-content:flex-end;gap:8px;margin-top:10px}
.modal-header{display:flex;justify-content:space-between;align-items:center;flex-shrink:0}
.modal-header h3{margin:0;font-size:16px}
.modal-header-left,.reasoning-header-left,.overview-header-left{display:flex;align-items:center;gap:8px;min-width:0}
.modal-body{flex:1;display:flex;min-height:0;margin-top:10px}
.modal-body textarea{flex:1;min-height:180px}
.fullscreen-btn{width:28px;height:28px;padding:0;display:inline-flex;align-items:center;justify-content:center}
.fullscreen-btn svg{width:14px;height:14px;display:block}
.modal.fullscreen,.reasoning-modal.fullscreen,.overview-modal.fullscreen{width:100vw !important;height:100vh !important;max-width:none !important;max-height:none !important;border-radius:0 !important}
.modal.fullscreen .modal-body textarea{resize:none}

.reasoning-modal{
  width:min(800px,92vw);
  height:70vh;
  background:#fff;
  border-radius:12px;
  display:flex;
  flex-direction:column;
  overflow:hidden;
  box-shadow:0 10px 40px rgba(0,0,0,.15)
}
.reasoning-header{
  padding:12px 16px;
  border-bottom:1px solid #ddd;
  display:flex;
  justify-content:space-between;
  align-items:center;
  flex-shrink:0
}
.reasoning-title{font-size:16px;font-weight:600;color:#111}
.reasoning-actions{display:flex;gap:6px}
.reasoning-body{flex:1;overflow-y:auto;padding:16px;position:relative}
.reasoning-content{line-height:1.65;font-size:14px;color:#222}
.reasoning-textarea{
  position:absolute;inset:16px;width:calc(100% - 32px);height:calc(100% - 32px);
  border:1px solid #ccc;border-radius:8px;padding:10px;font-family:inherit;
  font-size:14px;line-height:1.5;resize:none;outline:none;box-sizing:border-box;
  background:#fff;color:#111
}
.reasoning-textarea:focus{border-color:#111}

.overview-modal-mask{position:fixed;inset:0;background:rgba(0,0,0,.32);display:none;align-items:center;justify-content:center;z-index:100}
.overview-modal{
  width:min(900px,96vw);
  height:80vh;
  background:#fff;
  border-radius:12px;
  display:flex;
  flex-direction:column;
  overflow:hidden;
  box-shadow:0 10px 40px rgba(0,0,0,.15)
}
.overview-header{
  padding:12px 16px;
  border-bottom:1px solid #ddd;
  display:flex;
  justify-content:space-between;
  align-items:center;
  flex-shrink:0
}
.overview-title{font-size:16px;font-weight:600}
.overview-search-area{display:flex;gap:8px;align-items:center}
.overview-body{flex:1;overflow-y:auto;padding:12px}
.overview-item{border:1px solid #ddd;border-radius:8px;margin-bottom:8px;background:#fff}
.overview-item-header{
  display:flex;
  justify-content:space-between;
  align-items:center;
  padding:8px 12px;
  background:#f3f3f3;
  border-bottom:1px solid #ddd
}
.overview-item-role{font-size:12px;font-weight:600;color:#222}
.overview-item-actions{display:flex;gap:4px}
.overview-item-content{padding:10px 12px;font-size:14px;line-height:1.6;min-width:0}
.overview-item-preview{overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;white-space:pre-wrap}
.overview-item-full{display:none}
.overview-item-footer{padding:4px 12px 8px;display:flex;justify-content:flex-end}
.overview-item .msg-content{margin:0}
.overview-search-area input{
  padding:4px 8px;
  border:1px solid #ccc;
  border-radius:6px;
  font-size:12px;
  background:#fff;
  color:#111
}
</style>
</head>
<body>
<div class="app" id="app">
  <div id="backdrop" class="backdrop"></div>
  <aside id="side" class="side">
    <div class="side-top">
      <button id="newBtn" class="btn primary">+ 新建</button>
    </div>
    <div class="side-actions">
      <input id="searchInput" class="search-input" placeholder="输入关键词搜索..." />
      <button id="bulkModeBtn" class="btn">批量管理</button>
      <button id="wideModeBtn" class="btn" title="切换宽屏模式">&lt;|&gt;</button>
      <button id="overviewBtn" class="btn">总览</button>
      <button id="searchBtn" class="btn">搜索</button>
      <button id="selectAllBtn" class="btn" style="display:none;">全选</button>
      <button id="bulkPinBtn" class="btn" style="display:none;">置顶</button>
      <button id="bulkUnpinBtn" class="btn" style="display:none;">取消置顶</button>
      <button id="bulkDelBtn" class="btn danger" style="display:none;">删除</button>
      <button id="bulkCancelBtn" class="btn" style="display:none;">取消</button>
    </div>
    <div id="history" class="history"></div>
  </aside>

  <main class="main">
    <div class="top">
      <div style="display:flex;align-items:center;gap:8px;min-width:0;">
        <button id="openSideBtn" class="btn mobile-toggle">&#9776;</button>
        <div style="min-width:0;">
          <h1 id="chatTitle" class="title" title="双击编辑标题">新会话</h1>
          <div id="chatHint" class="hint"></div>
        </div>
      </div>
      <select id="modelSelect"></select>
    </div>

    <section id="msgs" class="msgs"></section>

    <footer class="composer">
      <div class="composer-inner">
        <textarea id="input" rows="3" placeholder="输入消息（Enter发送，Shift+Enter换行，可拖入文件上传）"></textarea>
        <div class="row">
          <div style="display:flex;gap:8px;align-items:center;min-width:0;">
            <button id="uploadBtn" class="btn">上传文件</button>
            <input id="fileInput" type="file" multiple style="display:none" />
            <div id="attachList" class="attach-list"></div>
          </div>
          <button id="sendBtn" class="btn primary">发送</button>
        </div>
      </div>
    </footer>
  </main>
</div>

<div id="editModalMask" class="modal-mask">
  <div id="editModal" class="modal">
    <div class="modal-header">
      <div class="modal-header-left">
        <button id="editFullscreenBtn" class="btn iconbtn fullscreen-btn" title="切换全屏" aria-label="切换全屏">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 3 21 3 21 9"></polyline>
            <polyline points="9 21 3 21 3 15"></polyline>
            <line x1="21" y1="3" x2="14" y2="10"></line>
            <line x1="3" y1="21" x2="10" y2="14"></line>
          </svg>
        </button>
        <h3>编辑消息</h3>
      </div>
    </div>
    <div class="modal-body">
      <textarea id="editModalText"></textarea>
    </div>
    <div class="ops">
      <button id="editCancelBtn" class="btn">取消</button>
      <button id="editSaveBtn" class="btn primary">保存</button>
    </div>
  </div>
</div>

<div id="reasoningModalMask" class="modal-mask">
  <div id="reasoningModal" class="reasoning-modal">
    <div class="reasoning-header">
      <div class="reasoning-header-left">
        <button id="reasoningFullscreenBtn" class="btn iconbtn fullscreen-btn" title="切换全屏" aria-label="切换全屏">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 3 21 3 21 9"></polyline>
            <polyline points="9 21 3 21 3 15"></polyline>
            <line x1="21" y1="3" x2="14" y2="10"></line>
            <line x1="3" y1="21" x2="10" y2="14"></line>
          </svg>
        </button>
        <div class="reasoning-title">思考过程</div>
      </div>
      <div class="reasoning-actions">
        <button id="reasoningEditBtn" class="btn">编辑</button>
        <button id="reasoningCloseBtn" class="btn">关闭</button>
      </div>
    </div>
    <div class="reasoning-body">
      <div id="reasoningView" class="reasoning-content"></div>
      <textarea id="reasoningTextarea" class="reasoning-textarea" style="display:none;"></textarea>
    </div>
  </div>
</div>

<div id="overviewModalMask" class="overview-modal-mask">
  <div id="overviewModal" class="overview-modal">
    <div class="overview-header">
      <div class="overview-header-left">
        <button id="overviewFullscreenBtn" class="btn iconbtn fullscreen-btn" title="切换全屏" aria-label="切换全屏">
          <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <polyline points="15 3 21 3 21 9"></polyline>
            <polyline points="9 21 3 21 3 15"></polyline>
            <line x1="21" y1="3" x2="14" y2="10"></line>
            <line x1="3" y1="21" x2="10" y2="14"></line>
          </svg>
        </button>
        <div class="overview-title">聊天总览</div>
      </div>
      <div class="overview-search-area">
        <input id="overviewSearchInput" type="text" placeholder="搜索当前聊天...">
        <button id="overviewCloseBtn" class="btn">关闭</button>
      </div>
    </div>
    <div id="overviewContent" class="overview-body"></div>
  </div>
</div>

<script>
const state = {
  id:null,title:'新会话',messages:[],
  source:null,generating:false,history:[],
  bulkMode:false,selected:new Set(),
  lastAssistantModel:'',searchKey:'',
  attachments:[],
  editingIndex:-1,
  searchMode:false,
  searchHits:{},
  autoScroll:true,
  titleLocked:false,
  currentReasoning:'',
  isReasoning:false,
  reasoningMsgIndex:-1,
  viewingReasoningIndex:-1,
  isEditingReasoning:false,
  currentStopToken:'',
  wideMode:false
};

const $ = id => document.getElementById(id);

const els = {
  app:$('app'),
  side:$('side'),backdrop:$('backdrop'),history:$('history'),
  openSideBtn:$('openSideBtn'),newBtn:$('newBtn'),searchBtn:$('searchBtn'),searchInput:$('searchInput'),
  selectAllBtn:$('selectAllBtn'),
  chatTitle:$('chatTitle'),chatHint:$('chatHint'),
  msgs:$('msgs'),input:$('input'),sendBtn:$('sendBtn'),modelSelect:$('modelSelect'),
  bulkModeBtn:$('bulkModeBtn'),bulkPinBtn:$('bulkPinBtn'),bulkUnpinBtn:$('bulkUnpinBtn'),
  bulkDelBtn:$('bulkDelBtn'),bulkCancelBtn:$('bulkCancelBtn'),
  uploadBtn:$('uploadBtn'),fileInput:$('fileInput'),attachList:$('attachList'),
  wideModeBtn:$('wideModeBtn'),

  editModalMask:$('editModalMask'),
  editModal:$('editModal'),
  editModalText:$('editModalText'),
  editFullscreenBtn:$('editFullscreenBtn'),
  editCancelBtn:$('editCancelBtn'),
  editSaveBtn:$('editSaveBtn'),

  overviewBtn:$('overviewBtn'),
  overviewModalMask:$('overviewModalMask'),
  overviewModal:$('overviewModal'),
  overviewContent:$('overviewContent'),
  overviewSearchInput:$('overviewSearchInput'),
  overviewCloseBtn:$('overviewCloseBtn'),
  overviewFullscreenBtn:$('overviewFullscreenBtn'),

  reasoningModalMask:$('reasoningModalMask'),
  reasoningModal:$('reasoningModal'),
  reasoningView:$('reasoningView'),
  reasoningTextarea:$('reasoningTextarea'),
  reasoningEditBtn:$('reasoningEditBtn'),
  reasoningCloseBtn:$('reasoningCloseBtn'),
  reasoningFullscreenBtn:$('reasoningFullscreenBtn')
};

const fullscreenEnterSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>';
const fullscreenExitSvg = '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 14 10 14 10 20"></polyline><polyline points="20 10 14 10 14 4"></polyline><line x1="14" y1="10" x2="21" y2="3"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>';

function setModalFullscreenBtn(btn, on){
  if (!btn) return;
  btn.innerHTML = on ? fullscreenExitSvg : fullscreenEnterSvg;
  btn.title = on ? '恢复原状' : '切换全屏';
  btn.setAttribute('aria-label', on ? '恢复原状' : '切换全屏');
}
function toggleModalFullscreen(modal, btn){
  if (!modal) return;
  const on = modal.classList.toggle('fullscreen');
  setModalFullscreenBtn(btn, on);
}
function resetModalFullscreen(modal, btn){
  if (!modal) return;
  modal.classList.remove('fullscreen');
  setModalFullscreenBtn(btn, false);
}

function setWideMode(on){
  state.wideMode = !!on;
  if (state.wideMode) {
    els.app.classList.add('wide-mode');
    els.wideModeBtn.textContent = '>|<';
  } else {
    els.app.classList.remove('wide-mode');
    els.wideModeBtn.textContent = '<|>';
  }
}

function esc(s){
  if (!s) return '';
  return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function md(text){ return '<div class="md">' + marked.parse(text || '') + '</div>'; }

function prettyModelName(model){
  if (!model) return 'Assistant';
  return model.split('-').map(function(seg){ return seg ? seg.charAt(0).toUpperCase() + seg.slice(1) : ''; }).join(' ');
}
function setHeader(){
  els.chatTitle.textContent = state.title || '新会话';
  els.chatHint.textContent = state.id ? ('ID: ' + state.id) : '';
}
function setSendBtn(){
  els.sendBtn.textContent = state.generating ? '停止' : '发送';
  els.sendBtn.className = state.generating ? 'btn warn' : 'btn primary';
}
function openSide(){ els.side.classList.add('open'); els.backdrop.classList.add('show'); }
function closeSide(){ els.side.classList.remove('open'); els.backdrop.classList.remove('show'); }

function setSearchMode(on){
  state.searchMode = on;
  els.searchInput.style.display = on ? 'block' : 'none';
  els.bulkModeBtn.style.display = on ? 'none' : '';
  els.wideModeBtn.style.display = on ? 'none' : '';
  els.overviewBtn.style.display = on ? 'none' : '';
  if (!on) {
    state.searchKey = '';
    state.searchHits = {};
    els.searchInput.value = '';
    renderHistory();
  } else {
    setTimeout(function(){ els.searchInput.focus(); }, 0);
  }
  els.searchBtn.textContent = on ? '取消搜索' : '搜索';
}

function copyText(text){
  if (navigator.clipboard && window.isSecureContext) return navigator.clipboard.writeText(text);
  const ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } finally { document.body.removeChild(ta); }
  return Promise.resolve();
}

function normalizeLatexText(t){
  if (!t) return '';
  let x = t;
  x = x.replace(/\\$$/g, '$$').replace(/\\$$/g, '$$');
  x = x.replace(/\\$/g, '$').replace(/\\$/g, '$');
  return x;
}

function wrapElWithXScroll(el, cls){
  if (!el || !el.parentNode) return null;
  if (el.parentNode.classList && el.parentNode.classList.contains('x-scroll')) return el.parentNode;
  const wrap = document.createElement('div');
  wrap.className = 'x-scroll ' + (cls || '');
  el.parentNode.insertBefore(wrap, el);
  wrap.appendChild(el);
  return wrap;
}

function wrapOverflowContent(root){
  if (!root) return;

  root.querySelectorAll('table').forEach(function(table){
    wrapElWithXScroll(table, 'table-wrap');
  });

  root.querySelectorAll('pre').forEach(function(pre){
    wrapElWithXScroll(pre, 'code-wrap');
  });

  root.querySelectorAll('mjx-container[display="true"], .MathJax_Display, svg[data-mml-node="math"]').forEach(function(node){
    wrapElWithXScroll(node, 'mj-wrap');
  });
}

function captureInteractiveState(root){
  const xScrolls = [];
  const details = [];
  if (!root) return {xScrolls, details};

  root.querySelectorAll('.x-scroll').forEach(function(el, i){
    xScrolls.push({ index:i, scrollLeft:el.scrollLeft });
  });

  root.querySelectorAll('details').forEach(function(el, i){
    details.push({ index:i, open:el.open });
  });

  return {xScrolls, details};
}

function restoreInteractiveState(root, snapshot){
  if (!root || !snapshot) return;

  const scrollEls = root.querySelectorAll('.x-scroll');
  (snapshot.xScrolls || []).forEach(function(item){
    const el = scrollEls[item.index];
    if (el) el.scrollLeft = item.scrollLeft || 0;
  });

  const detailEls = root.querySelectorAll('details');
  (snapshot.details || []).forEach(function(item){
    const el = detailEls[item.index];
    if (el) el.open = !!item.open;
  });
}

function renderRich(el, snapshot){
  if (!el) return;

  const applyWrapAndRestore = function(){
    wrapOverflowContent(el);
    if (snapshot) restoreInteractiveState(el, snapshot);
  };

  if (window.MathJax) {
    MathJax.typesetPromise([el]).catch(function(){})
    .then(function(){
      applyWrapAndRestore();
    });
  } else {
    applyWrapAndRestore();
  }

  const blocks = el.querySelectorAll('pre code.language-mermaid, pre code.lang-mermaid');
  blocks.forEach(function(code, i){
    const pre = code.closest('pre');
    if (!pre) return;
    const src = code.textContent || '';
    const holder = document.createElement('div');
    const id = 'mmd_' + Date.now() + '_' + i + '_' + Math.random().toString(16).slice(2);
    holder.className = 'mermaid';
    holder.id = id;
    holder.textContent = src;
    pre.replaceWith(holder);
  });

  if (window.mermaid) {
    mermaid.run({ nodes: el.querySelectorAll('.mermaid') }).catch(function(){})
      .finally(function(){
        applyWrapAndRestore();
      });
  } else {
    applyWrapAndRestore();
  }
}

function renderUserAttachments(m){
  const atts = Array.isArray(m.attachments) ? m.attachments : [];
  if (!atts.length) return '';
  return '<div class="attach-list" style="margin-top:8px;">' + atts.map(function(a){
    const name = esc(a.name || 'file');
    const url = esc(a.url || '#');
    const size = a.size ? (' ' + Math.round(a.size/1024) + 'KB') : '';
    return '<span class="attach-chip"><a class="attach-link" href="' + url + '" target="_blank" rel="noopener">' + name + '</a><span>' + size + '</span></span>';
  }).join('') + '</div>';
}

function renderMessageContentHtml(m){
  return '<div class="msg-content">' + md(normalizeLatexText(m.content || '')) + '</div>';
}

function addMsgDom(m, idx){
  const div = document.createElement('div');
  div.className = 'msg ' + m.role;
  div.dataset.idx = String(idx);
  const roleText = m.role === 'assistant' ? prettyModelName(m.model || state.lastAssistantModel || els.modelSelect.value) : 'User';

  const hasReasoning = m.role === 'assistant' && ((m.reasoning_content != null && m.reasoning_content !== '') || (state.isReasoning && idx === state.reasoningMsgIndex));
  const isCurrentlyReasoning = state.isReasoning && idx === state.reasoningMsgIndex;

  let headerHtml = '';
  if (m.role === 'assistant') {
    let reasoningBtnText = '';
    let reasoningBtnClass = 'reasoning-btn';
    if (isCurrentlyReasoning) {
      reasoningBtnText = '思考中...';
      reasoningBtnClass += ' thinking';
    } else if (hasReasoning) {
      reasoningBtnText = '思考过程';
    }
    headerHtml = '<div class="msg-header">'
      + '<span class="role">' + esc(roleText) + '</span>'
      + (reasoningBtnText ? '<button class="' + reasoningBtnClass + '" data-idx="' + idx + '">' + reasoningBtnText + '</button>' : '')
      + '</div>';
  } else {
    headerHtml = '';
  }

  div.innerHTML = ''
    + headerHtml
    + renderMessageContentHtml(m)
    + (m.role === 'user' ? renderUserAttachments(m) : '')
    + '<div class="msg-actions">'
    + '<button class="btn iconbtn act-copy">复制</button>'
    + '<button class="btn iconbtn act-edit">编辑</button>'
    + '<button class="btn iconbtn act-retry">重试</button>'
    + '<button class="btn iconbtn act-del">删除</button>'
    + '</div>';

  const reasoningBtn = div.querySelector('.reasoning-btn');
  if (reasoningBtn) {
    reasoningBtn.onclick = function(e){
      e.stopPropagation();
      openReasoningModal(idx);
    };
  }

  bindMsgActions(div);
  els.msgs.appendChild(div);
  renderRich(div);
  return div;
}

function rerenderMessages(){
  els.msgs.innerHTML='';
  state.messages.forEach(function(m,i){ addMsgDom(m,i); });
  if(state.autoScroll) els.msgs.scrollTop = els.msgs.scrollHeight;
}

function updateMessageContentDom(idx){
  const div = els.msgs.querySelector('.msg[data-idx="' + idx + '"]');
  if (!div) return;
  const contentEl = div.querySelector('.msg-content');
  if (!contentEl) return;

  const snapshot = captureInteractiveState(contentEl);
  contentEl.outerHTML = renderMessageContentHtml(state.messages[idx] || {content:''});
  const newContentEl = div.querySelector('.msg-content');
  renderRich(newContentEl, snapshot);
}

function openEditModal(index){
  state.editingIndex = index;
  els.editModalText.value = state.messages[index] ? (state.messages[index].content || '') : '';
  setModalFullscreenBtn(els.editFullscreenBtn, els.editModal.classList.contains('fullscreen'));
  els.editModalMask.style.display = 'flex';
  els.editModalText.focus();
}
function closeEditModal(){
  els.editModalMask.style.display = 'none';
  state.editingIndex = -1;
  resetModalFullscreen(els.editModal, els.editFullscreenBtn);
}

function getReasoningTextByIndex(index){
  if (state.isReasoning && index === state.reasoningMsgIndex) return state.currentReasoning;
  const msg = state.messages[index];
  return (msg && msg.reasoning_content) ? msg.reasoning_content : '';
}

function openReasoningModal(index){
  state.viewingReasoningIndex = index;
  state.isEditingReasoning = false;

  const canOpen = (state.isReasoning && index === state.reasoningMsgIndex) ||
                  (state.messages[index] && typeof state.messages[index].reasoning_content !== 'undefined');

  if (!canOpen) return;

  const reasoningText = getReasoningTextByIndex(index);

  els.reasoningView.style.display = 'block';
  els.reasoningTextarea.style.display = 'none';
  els.reasoningView.innerHTML = md(normalizeLatexText(reasoningText));
  els.reasoningEditBtn.textContent = '编辑';
  els.reasoningEditBtn.style.display = '';
  setModalFullscreenBtn(els.reasoningFullscreenBtn, els.reasoningModal.classList.contains('fullscreen'));
  els.reasoningModalMask.style.display = 'flex';
  renderRich(els.reasoningView);
}
function closeReasoningModal(){
  els.reasoningModalMask.style.display = 'none';
  state.viewingReasoningIndex = -1;
  state.isEditingReasoning = false;
  resetModalFullscreen(els.reasoningModal, els.reasoningFullscreenBtn);
}

function toggleReasoningEdit(){
  const idx = state.viewingReasoningIndex;
  if (idx < 0) return;

  if (state.isEditingReasoning) {
    const newContent = els.reasoningTextarea.value;

    if (state.isReasoning && idx === state.reasoningMsgIndex) {
      state.currentReasoning = newContent;
    } else if (state.messages[idx]) {
      state.messages[idx].reasoning_content = newContent;
      persistMessages();
    }

    els.reasoningView.innerHTML = md(normalizeLatexText(newContent));
    els.reasoningView.style.display = 'block';
    els.reasoningTextarea.style.display = 'none';
    els.reasoningEditBtn.textContent = '编辑';
    state.isEditingReasoning = false;
    renderRich(els.reasoningView);

    if (state.messages[idx] && state.messages[idx].role === 'assistant') {
      updateReasoningButton(idx, state.isReasoning && idx === state.reasoningMsgIndex, true);
    }
  } else {
    els.reasoningTextarea.value = getReasoningTextByIndex(idx);
    els.reasoningView.style.display = 'none';
    els.reasoningTextarea.style.display = 'block';
    els.reasoningEditBtn.textContent = '保存';
    state.isEditingReasoning = true;
    els.reasoningTextarea.focus();
  }
}

function updateReasoningButton(index, isThinking, hasContent){
  let btn = els.msgs.querySelector('.reasoning-btn[data-idx="' + index + '"]');

  if (!btn) {
    const msgDiv = els.msgs.querySelector('.msg[data-idx="' + index + '"]');
    if (msgDiv) {
      const header = msgDiv.querySelector('.msg-header');
      if (header) {
        btn = document.createElement('button');
        btn.className = 'reasoning-btn';
        btn.dataset.idx = index;
        btn.onclick = function(e){ e.stopPropagation(); openReasoningModal(index); };
        header.appendChild(btn);
      }
    }
  }

  if (!btn) return;

  if (isThinking) {
    btn.textContent = '思考中...';
    btn.className = 'reasoning-btn thinking';
  } else if (hasContent) {
    btn.textContent = '思考过程';
    btn.className = 'reasoning-btn';
  }
}

function bindMsgActions(div){
  const idx = Number(div.dataset.idx);
  const btnCopy = div.querySelector('.act-copy');
  btnCopy.onclick = function(){
    copyText((state.messages[idx] && state.messages[idx].content) || '').then(function(){
      const originText = btnCopy.textContent;
      btnCopy.textContent = '已复制';
      btnCopy.style.color = '#111';
      setTimeout(function(){ btnCopy.textContent = originText; btnCopy.style.color = ''; }, 1500);
    });
  };
  div.querySelector('.act-edit').onclick = function(){ openEditModal(idx); };
  div.querySelector('.act-del').onclick = function(){
    if (!confirm('删除这条消息？')) return;
    state.messages.splice(idx,1);
    persistMessages().then(function(){ rerenderMessages(); });
  };
  div.querySelector('.act-retry').onclick = function(){
    let userText = '';
    for (let i=idx;i>=0;i--) {
      if(state.messages[i].role==='user'){ userText=state.messages[i].content; break; }
    }
    if (!userText){
      for (let i=state.messages.length-1;i>=0;i--) {
        if(state.messages[i].role==='user'){ userText=state.messages[i].content; break; }
      }
    }
    if (!userText) return alert('没有可重试的用户消息');
    let cut=-1;
    for(let i=idx;i>=0;i--){ if(state.messages[i].role==='user'){ cut=i; break; } }
    if (cut>=0) state.messages = state.messages.slice(0,cut+1);
    else state.messages.push({role:'user',content:userText});
    persistMessages().then(function(){
      rerenderMessages();
      sendWithText(userText,true);
    });
  };
}

async function persistMessages(){
  if (!state.id) return;
  await fetch('?action=update_messages',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({id:state.id,messages:state.messages})
  });
  await loadHistory();
}

function updateBulkUI(){
  const on=state.bulkMode;
  els.bulkPinBtn.style.display=on?'':'none';
  els.bulkUnpinBtn.style.display=on?'':'none';
  els.bulkDelBtn.style.display=on?'':'none';
  els.bulkCancelBtn.style.display=on?'':'none';
  els.searchBtn.style.display = on ? 'none' : '';
  els.overviewBtn.style.display = on ? 'none' : '';
  els.wideModeBtn.style.display = on ? 'none' : '';
  els.selectAllBtn.style.display = on ? '' : 'none';
  if (!state.searchMode) els.bulkModeBtn.style.display=on?'none':'';
}

function highlightTitle(title, key){
  const t = title || '';
  if (!key) return esc(t);
  const i = t.toLowerCase().indexOf(key.toLowerCase());
  if (i < 0) return esc(t);
  return esc(t.slice(0,i)) + '<mark class="hl">' + esc(t.slice(i,i+key.length)) + '</mark>' + esc(t.slice(i+key.length));
}
function highlightText(text, key){
  const t = text || '';
  if (!key) return esc(t);
  const i = t.toLowerCase().indexOf(key.toLowerCase());
  if (i < 0) return esc(t);
  return esc(t.slice(0,i)) + '<mark class="hl">' + esc(t.slice(i,i+key.length)) + '</mark>' + esc(t.slice(i+key.length));
}
function highlightAll(text, key){
  if (!key) return esc(text || '');
  const t = text || '';
  const safeKey = key.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  try {
    const regex = new RegExp('(' + safeKey + ')', 'gi');
    const parts = t.split(regex);
    return parts.map(function(part){
      if (part.toLowerCase() === key.toLowerCase()) return '<mark class="hl">' + esc(part) + '</mark>';
      return esc(part);
    }).join('');
  } catch(e) {
    return esc(t);
  }
}
function findHitsFromMessages(messages, key){
  const kw = (key || '').toLowerCase();
  if (!kw) return [];
  const hits = [];
  for (let i = 0; i < (messages || []).length; i++) {
    const txt = String((messages[i] && messages[i].content) || '');
    let searchPos = 0;
    while (true) {
      const p = txt.toLowerCase().indexOf(kw, searchPos);
      if (p < 0) break;
      const start = Math.max(0, p - 16);
      const end = Math.min(txt.length, p + kw.length + 24);
      const snippet = (start > 0 ? '...' : '') + txt.slice(start, end).replace(/\s+/g, ' ') + (end < txt.length ? '...' : '');
      hits.push({ index:i, snippet:snippet });
      searchPos = p + kw.length;
      if (hits.length > 200) break;
    }
  }
  return hits;
}

const lockSvg = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>';
const unlockSvg = '<svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"></rect><path d="M7 11V7a5 5 0 0 1 9.9-1"></path></svg>';

function renderHistory(){
  els.history.innerHTML='';
  let view = state.history;

  if (state.searchKey) {
    const k = state.searchKey.toLowerCase();
    view = view.filter(function(it){
      const titleHit = (it.title || '').toLowerCase().indexOf(k) >= 0;
      const contentHit = !!(state.searchHits[it.id] && state.searchHits[it.id].length > 0);
      return titleHit || contentHit;
    });
  }

  view.forEach(function(it){
    const active = it.id===state.id?' active':'';
    const checked = state.selected.has(it.id)?'checked':'';
    const pinBadge = it.pinned?'<span class="badge">置顶</span>':'';
    const isLocked = it.title_locked || false;
    const hits = state.searchHits[it.id] || [];
    let hitsHtml = '';
    const maxDisplay = 3;

    if (hits.length > 0) {
      const displayHits = hits.slice(0, maxDisplay);
      hitsHtml = displayHits.map(function(hit){
        return '<div class="item-hit" data-hit-id="'+it.id+'" data-hit-idx="'+hit.index+'">命中：' + highlightText(hit.snippet, state.searchKey) + '</div>';
      }).join('');
      if (hits.length > maxDisplay) {
        const hiddenCount = hits.length - maxDisplay;
        hitsHtml += '<div class="expand-hits" data-id="'+it.id+'">还有 ' + hiddenCount + ' 个命中...</div>';
        hitsHtml += '<div class="hidden-hits">' + hits.slice(maxDisplay).map(function(hit){
          return '<div class="item-hit" data-hit-id="'+it.id+'" data-hit-idx="'+hit.index+'">命中：' + highlightText(hit.snippet, state.searchKey) + '</div>';
        }).join('') + '</div>';
      }
    }

    const div = document.createElement('div');
    div.className='item'+active;
    div.draggable=!state.bulkMode;
    div.dataset.id=it.id;

    div.innerHTML=''
      + '<div class="item-top">'
      + (state.bulkMode?('<input type="checkbox" class="sel" data-id="'+it.id+'" '+checked+'>'):'')
      + '<div class="item-title" title="' + (isLocked ? '标题已锁定' : '双击重新生成标题') + '">' + highlightTitle(it.title || '无标题', state.searchKey) + '</div>'
      + pinBadge
      + '<button class="lock-btn ' + (isLocked ? 'locked' : '') + '" data-id="'+it.id+'" title="'+(isLocked?'点击解锁标题':'点击锁定标题')+'">' + (isLocked ? lockSvg : unlockSvg) + '</button>'
      + '</div>'
      + hitsHtml
      + '<div class="item-meta">'+new Date(it.updated_at*1000).toLocaleString()+'</div>'
      + '<div class="item-ops">'
      + '<button class="btn iconbtn op-clone">克隆</button>'
      + '<button class="btn iconbtn op-pin">'+(it.pinned?'取消置顶':'置顶')+'</button>'
      + '<button class="btn iconbtn op-del">删除</button>'
      + '</div>';

    div.onclick = function(e){
      if (state.bulkMode) return;
      if (e.target.closest('button') || e.target.closest('input') || e.target.closest('.item-hit') || e.target.closest('.expand-hits') || e.target.closest('.item-title')) return;
      loadChat(it.id);
    };

    div.querySelector('.lock-btn').onclick = function(e){
      e.stopPropagation();
      toggleLock(it.id);
    };

    div.querySelectorAll('.item-hit').forEach(function(el){
      el.onclick = function(e){
        e.stopPropagation();
        const idx = Number(el.dataset.hitIdx);
        loadChat(it.id, idx);
      };
    });

    div.querySelectorAll('.expand-hits').forEach(function(el){
      el.onclick = function(e){
        e.stopPropagation();
        const hidden = div.querySelector('.hidden-hits');
        if (hidden) {
          if(hidden.classList.contains('show')){
            hidden.classList.remove('show');
            el.textContent = '还有 ' + hidden.children.length + ' 个命中...';
          } else {
            hidden.classList.add('show');
            el.textContent = '收起';
          }
        }
      };
    });

    div.querySelector('.op-clone').onclick = function(e){
      e.stopPropagation();
      if(!confirm('克隆该会话？')) return;
      fetch('?action=clone',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:it.id})
      }).then(function(res){ return res.json(); }).then(function(j){
        if(j.ok){
          loadHistory().then(function(){
            if(j.new_id) loadChat(j.new_id);
          });
        } else {
          alert(j.error || '克隆失败');
        }
      });
    };

    const titleEl = div.querySelector('.item-title');
    let titleClickTimer = null;
    titleEl.onclick = function(e){
      e.stopPropagation();
      if (state.bulkMode) return;
      clearTimeout(titleClickTimer);
      titleClickTimer = setTimeout(function(){ loadChat(it.id); }, 220);
    };
    titleEl.ondblclick = function(e){
      e.stopPropagation();
      if (state.bulkMode) return;
      clearTimeout(titleClickTimer);
      if (it.title_locked) return;
      regenerateChatTitle(it.id, titleEl);
    };

    div.querySelector('.op-del').onclick = function(e){
      e.stopPropagation();
      if(!confirm('删除该会话？')) return;
      fetch('?action=delete',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:it.id})
      }).then(function(){
        if(state.id===it.id) newChat();
        loadHistory();
      });
    };

    div.querySelector('.op-pin').onclick = function(e){
      e.stopPropagation();
      fetch('?action=bulk_pin',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ids:[it.id],pin:!it.pinned})
      }).then(function(){ loadHistory(); });
    };

    const sel = div.querySelector('.sel');
    if(sel) sel.onchange=function(e){
      e.stopPropagation();
      const id=e.target.dataset.id;
      if(e.target.checked) state.selected.add(id); else state.selected.delete(id);
      const viewIds = view.map(function(x){ return x.id; });
      const allSelected = viewIds.length > 0 && viewIds.every(function(xid){ return state.selected.has(xid); });
      els.selectAllBtn.textContent = allSelected ? '取消全选' : '全选';
    };

    div.addEventListener('dragstart', function(e){
      div.classList.add('dragging');
      e.dataTransfer.setData('text/plain', it.id);
      e.dataTransfer.effectAllowed='move';
    });
    div.addEventListener('dragend', function(){ div.classList.remove('dragging'); });
    div.addEventListener('dragover', function(e){
      if (state.bulkMode) return;
      e.preventDefault();
      div.classList.add('drag-over');
    });
    div.addEventListener('dragleave', function(){ div.classList.remove('drag-over'); });
    div.addEventListener('drop', function(e){
      e.preventDefault();
      div.classList.remove('drag-over');
      if (state.bulkMode) return;
      const fromId=e.dataTransfer.getData('text/plain');
      const toId=it.id;
      if(!fromId || fromId===toId) return;
      const arr=state.history.map(function(x){ return x.id; });
      const fi=arr.indexOf(fromId), ti=arr.indexOf(toId);
      if(fi<0||ti<0) return;
      const m=arr.splice(fi,1)[0];
      arr.splice(ti,0,m);
      fetch('?action=reorder',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({ids:arr})
      }).then(function(){ loadHistory(); });
    });

    els.history.appendChild(div);
  });

  if (state.bulkMode) {
    const viewIds = view.map(function(it){ return it.id; });
    const allSelected = viewIds.length > 0 && viewIds.every(function(id){ return state.selected.has(id); });
    els.selectAllBtn.textContent = allSelected ? '取消全选' : '全选';
  }
}

function toggleLock(id){
  fetch('?action=toggle_lock', {
    method: 'POST',
    headers: {'Content-Type':'application/json'},
    body: JSON.stringify({id: id})
  }).then(function(res){ return res.json(); }).then(function(j){
    if(j.ok){
      state.history.forEach(function(it){
        if(it.id === id) it.title_locked = j.locked;
      });
      renderHistory();
    } else {
      alert(j.error || '操作失败');
    }
  });
}

async function loadHistory(){
  const r=await fetch('?action=list');
  const j=await r.json();
  if (!j.ok) return;
  state.history=j.items||[];
  state.searchHits = {};

  const key = state.searchKey.trim();
  if (key) {
    const tasks = state.history.map(function(it){
      return fetch('?action=get&id=' + encodeURIComponent(it.id))
        .then(function(res){ return res.json(); })
        .then(function(jj){
          if (!jj.ok) return;
          const hits = findHitsFromMessages((jj.chat && jj.chat.messages) || [], key);
          if (hits.length > 0) state.searchHits[it.id] = hits;
        }).catch(function(){});
    });
    await Promise.all(tasks);
  }
  renderHistory();
}

async function loadModels(){
  const r=await fetch('?action=models');
  const j=await r.json();
  if (!j.ok) return;
  els.modelSelect.innerHTML='';
  (j.models||[]).forEach(function(m){
    const op=document.createElement('option');
    op.value=m;
    op.textContent=m;
    els.modelSelect.appendChild(op);
  });
  els.modelSelect.value=j.default||'';
}

function renderAttachmentList(){
  els.attachList.innerHTML='';
  state.attachments.forEach(function(a, idx){
    const chip=document.createElement('div');
    chip.className='attach-chip';
    const link = a.url ? ('<a class="attach-link" href="' + esc(a.url) + '" target="_blank" rel="noopener">' + esc(a.name) + '</a>') : ('<span>' + esc(a.name) + '</span>');
    chip.innerHTML=link + '<span class="attach-x">&times;</span>';
    chip.querySelector('.attach-x').onclick=function(){
      if(a.stored_name){
        fetch('?action=delete_file', {
          method:'POST',
          headers:{'Content-Type':'application/json'},
          body: JSON.stringify({name: a.stored_name})
        }).catch(function(){});
      }
      state.attachments.splice(idx,1);
      renderAttachmentList();
    };
    els.attachList.appendChild(chip);
  });
}

async function loadChat(id, jumpIndex=-1){
  if(state.generating && !confirm('当前在生成，确定切换？')) return;
  await stopGeneration(true);
  const r=await fetch('?action=get&id='+encodeURIComponent(id));
  const j=await r.json();
  if(!j.ok) return alert(j.error||'加载失败');
  state.id=j.chat.id;
  state.title=j.chat.title||'无标题';
  state.messages=j.chat.messages||[];
  state.titleLocked = j.chat.title_locked || false;
  setHeader();
  rerenderMessages();
  loadHistory();
  closeSide();

  if (jumpIndex >= 0) {
    state.autoScroll = false;
    setTimeout(function(){
      const target = els.msgs.querySelector('.msg[data-idx="'+jumpIndex+'"]');
      if (target) {
        target.scrollIntoView({ behavior:'smooth', block:'center' });
        target.style.boxShadow = '0 0 0 2px rgba(0,0,0,.25)';
        setTimeout(function(){ target.style.boxShadow=''; }, 1200);
      }
    }, 50);
  }
}

function stopClientOnly(){
  if(state.source){state.source.close();state.source=null;}
  state.generating=false;
  state.isReasoning=false;
  state.reasoningMsgIndex=-1;
  state.currentStopToken='';
  setSendBtn();
}

async function stopGeneration(silent){
  if (!state.generating) {
    stopClientOnly();
    return;
  }

  const token = state.currentStopToken;
  if (token) {
    try {
      await fetch('?action=stop_chat', {
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body: JSON.stringify({stop_token: token})
      });
    } catch (e) {}
  }

  if (state.source) {
    state.source.close();
    state.source = null;
  }

  state.generating = false;
  state.isReasoning = false;
  state.reasoningMsgIndex = -1;
  state.currentStopToken = '';
  setSendBtn();

  if (!silent) {
    setTimeout(function(){ loadHistory(); }, 300);
    setTimeout(function(){
      if (state.id) {
        fetch('?action=get&id='+encodeURIComponent(state.id))
          .then(function(r){ return r.json(); })
          .then(function(j){
            if(j.ok){
              state.messages = j.chat.messages || [];
              state.title = j.chat.title || state.title;
              setHeader();
              rerenderMessages();
            }
          }).catch(function(){});
      }
    }, 500);
  }
}

function newChat(){
  stopClientOnly();
  state.id=null;
  state.title='新会话';
  state.messages=[];
  state.attachments=[];
  state.autoScroll=true;
  state.titleLocked=false;
  state.currentReasoning='';
  state.isReasoning=false;
  state.reasoningMsgIndex=-1;
  state.currentStopToken='';
  setHeader();
  rerenderMessages();
  renderAttachmentList();
  loadHistory();
  closeSide();
}

function toggleSelectAll(){
  const view = state.searchKey
    ? state.history.filter(function(it){
        const titleHit = (it.title || '').toLowerCase().indexOf(state.searchKey.toLowerCase()) >= 0;
        const contentHit = !!state.searchHits[it.id];
        return titleHit || contentHit;
      })
    : state.history;

  const ids = view.map(function(it){ return it.id; });
  const allSelected = ids.length > 0 && ids.every(function(id){ return state.selected.has(id); });

  if (allSelected) {
    ids.forEach(function(id){ state.selected.delete(id); });
    els.selectAllBtn.textContent = '全选';
  } else {
    ids.forEach(function(id){ state.selected.add(id); });
    els.selectAllBtn.textContent = '取消全选';
  }
  renderHistory();
}

async function uploadOneFile(file){
  const fd = new FormData();
  fd.append('file', file);
  const r = await fetch('?action=upload', { method:'POST', body:fd });
  const j = await r.json();
  if (!j.ok) throw new Error(j.error || '上传失败');
  return j.file;
}

async function regenerateChatTitle(id, titleEl){
  if (!id) return;
  if (titleEl && titleEl.dataset.busy === '1') return;

  const oldHtml = titleEl ? titleEl.innerHTML : '';
  if (titleEl) {
    titleEl.dataset.busy = '1';
    titleEl.textContent = '生成中...';
    titleEl.style.opacity = '.65';
  }

  try {
    const r = await fetch('?action=title_ai', {
      method:'POST',
      headers:{'Content-Type':'application/json'},
      body:JSON.stringify({id:id})
    });
    const j = await r.json();
    if (!j.ok) throw new Error(j.error || '重新生成标题失败');

    if (j.locked || j.skipped) {
      await loadHistory();
      return;
    }

    if (state.id === id && j.title) {
      state.title = j.title;
      setHeader();
    }

    await loadHistory();
  } catch (e) {
    if (titleEl) titleEl.innerHTML = oldHtml || '无标题';
    alert((e && e.message) || '重新生成标题失败');
  } finally {
    if (titleEl) {
      titleEl.style.opacity = '';
      titleEl.removeAttribute('data-busy');
    }
  }
}

function hasDraggedFiles(dt){
  if (!dt) return false;
  if (dt.files && dt.files.length > 0) return true;
  const types = Array.from(dt.types || []);
  return types.indexOf('Files') !== -1;
}

async function handleSelectedFiles(fileList){
  const files = Array.from(fileList || []);
  if (!files.length) return;

  const maxAttachments = 6;
  const remain = Math.max(0, maxAttachments - state.attachments.length);

  if (remain <= 0) {
    alert('单次最多添加 6 个附件，请先移除一些附件再上传');
    return;
  }

  const queue = files.slice(0, remain);
  if (files.length > remain) {
    alert('最多再添加 ' + remain + ' 个附件，其余已跳过');
  }

  for (const f of queue) {
    if (f.size > 15 * 1024 * 1024) {
      alert(f.name + ' 超过 15MB，已跳过');
      continue;
    }
    try {
      const uploaded = await uploadOneFile(f);
      state.attachments.push({
        name: uploaded.name || f.name || 'file',
        mime: uploaded.mime || f.type || 'application/octet-stream',
        size: uploaded.size || f.size || 0,
        stored_name: uploaded.stored_name || '',
        url: uploaded.url || '',
        is_image: !!uploaded.is_image
      });
      renderAttachmentList();
    } catch (err) {
      alert(f.name + ' 上传失败: ' + (err && err.message ? err.message : '未知错误'));
    }
  }
}

function bindInputDragUpload(){
  document.addEventListener('dragover', function(e){
    if (hasDraggedFiles(e.dataTransfer)) e.preventDefault();
  });

  document.addEventListener('drop', function(e){
    if (!hasDraggedFiles(e.dataTransfer)) return;
    if (e.target !== els.input) e.preventDefault();
    els.input.classList.remove('dragover');
  });

  els.input.addEventListener('dragenter', function(e){
    if (!hasDraggedFiles(e.dataTransfer)) return;
    e.preventDefault();
    els.input.classList.add('dragover');
  });

  els.input.addEventListener('dragover', function(e){
    if (!hasDraggedFiles(e.dataTransfer)) return;
    e.preventDefault();
    e.dataTransfer.dropEffect = 'copy';
    els.input.classList.add('dragover');
  });

  els.input.addEventListener('dragleave', function(){
    els.input.classList.remove('dragover');
  });

  els.input.addEventListener('drop', function(e){
    if (!hasDraggedFiles(e.dataTransfer)) return;
    e.preventDefault();
    e.stopPropagation();
    els.input.classList.remove('dragover');
    handleSelectedFiles(e.dataTransfer.files);
    els.input.focus();
  });
}

async function createChatStream(message, model, attachments){
  const r = await fetch('?action=chat_prepare', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({
      id:state.id,
      model:model,
      message:message,
      attachments:attachments
    })
  });
  const j = await r.json();
  if (!j.ok || !j.token) throw new Error(j.error || '创建会话流失败');
  return j;
}

async function sendWithText(text, fromRetry){
  if(state.generating) return;
  const t=(text||'').trim();
  if(!t) return;

  state.generating=true;
  state.autoScroll = true;
  state.isReasoning = false;
  state.currentReasoning = '';
  state.currentStopToken = '';
  setSendBtn();

  const sendingAttachments = state.attachments.slice(0);
  state.attachments = [];
  renderAttachmentList();

  if(!fromRetry){
    state.messages.push({
      role:'user',
      content:t,
      attachments:sendingAttachments
    });
    addMsgDom(state.messages[state.messages.length-1], state.messages.length-1);
  }

  const currentModel=els.modelSelect.value;
  const a={role:'assistant',content:'',model:currentModel};
  state.messages.push(a);
  const aIdx=state.messages.length-1;
  const aDom=addMsgDom(a,aIdx);
  const roleEl=aDom.querySelector('.role');
  if(roleEl) roleEl.textContent=prettyModelName(currentModel);

  let es = null;
  try {
    const prep = await createChatStream(t, currentModel, sendingAttachments);
    if (prep.stop_token) state.currentStopToken = prep.stop_token;
    es = new EventSource('?action=chat&token=' + encodeURIComponent(prep.token));
    state.source = es;
  } catch (err) {
    alert((err && err.message) || '发送失败');
    state.messages.pop();
    if(!fromRetry) state.messages.pop();
    rerenderMessages();
    state.attachments = sendingAttachments.concat(state.attachments);
    renderAttachmentList();
    stopClientOnly();
    return;
  }

  es.onmessage=function(ev){
    let d={};
    try{ d=JSON.parse(ev.data); }catch(e){ return; }

    if(d.type==='meta'){
      if(d.id) state.id=d.id;
      if(d.title) state.title=d.title;
      if(d.stop_token) state.currentStopToken = d.stop_token;
      setHeader();
    }else if(d.type==='reasoning_start'){
      state.isReasoning = true;
      state.reasoningMsgIndex = aIdx;
      state.currentReasoning = '';
      updateReasoningButton(aIdx, true, false);

      if (els.reasoningModalMask.style.display === 'flex' && state.viewingReasoningIndex === aIdx) {
        if (!state.isEditingReasoning) {
          els.reasoningView.innerHTML = '';
          renderRich(els.reasoningView);
        }
      }
    }else if(d.type==='reasoning_delta'){
      if (!(state.isEditingReasoning && state.viewingReasoningIndex === aIdx)) {
        state.currentReasoning += d.text || '';
      }
      updateReasoningButton(aIdx, true, true);

      if (els.reasoningModalMask.style.display === 'flex' && state.viewingReasoningIndex === aIdx) {
        if (state.isEditingReasoning) {
        } else {
          const snap = captureInteractiveState(els.reasoningView);
          els.reasoningView.innerHTML = md(normalizeLatexText(state.currentReasoning));
          const body = els.reasoningModal.querySelector('.reasoning-body');
          if (body) body.scrollTop = body.scrollHeight;
          renderRich(els.reasoningView, snap);
        }
      }
    }else if(d.type==='reasoning_end'){
      state.isReasoning = false;
      state.messages[aIdx].reasoning_content = state.currentReasoning;
      updateReasoningButton(aIdx, false, true);
    }else if(d.type==='delta'){
      a.content += d.text || '';
      state.messages[aIdx].content = a.content;
      updateMessageContentDom(aIdx);
      if(state.autoScroll) els.msgs.scrollTop = els.msgs.scrollHeight;
    }else if(d.type==='title_updated'){
      if(d.title){
        state.title = d.title;
        setHeader();
        loadHistory();
      }
    }else if(d.type==='stopped'){
      if (state.isReasoning && state.reasoningMsgIndex === aIdx) {
        state.messages[aIdx].reasoning_content = state.currentReasoning;
      }
      stopClientOnly();
      if (state.id) {
        fetch('?action=get&id='+encodeURIComponent(state.id))
          .then(function(r){ return r.json(); })
          .then(function(j){
            if(j.ok){
              state.messages = j.chat.messages || state.messages;
              state.title = j.chat.title || state.title;
              setHeader();
              rerenderMessages();
              loadHistory();
            }
          }).catch(function(){ loadHistory(); });
      } else {
        loadHistory();
      }
    }else if(d.type==='done'){
      a.model=d.model||currentModel;
      state.lastAssistantModel=a.model;
      if(roleEl) roleEl.textContent=prettyModelName(a.model);
      if(d.title) state.title = d.title;
      if (state.isReasoning && state.reasoningMsgIndex === aIdx) {
        state.messages[aIdx].reasoning_content = state.currentReasoning;
      }
      setHeader();
      stopClientOnly();
      persistMessages().then(function(){ loadHistory(); });
    }else if(d.type==='error'){
      alert(d.message||'生成失败');
      stopClientOnly();
      if (d.partial_saved && state.id) {
        fetch('?action=get&id='+encodeURIComponent(state.id))
          .then(function(r){ return r.json(); })
          .then(function(j){
            if(j.ok){
              state.messages = j.chat.messages || state.messages;
              state.title = j.chat.title || state.title;
              setHeader();
              rerenderMessages();
              loadHistory();
            }
          }).catch(function(){ loadHistory(); });
      } else {
        persistMessages().then(function(){ loadHistory(); });
      }
    }
  };

  es.onerror=function(){
    if (!state.generating) return;
    stopClientOnly();
    setTimeout(function(){
      if (state.id) {
        fetch('?action=get&id='+encodeURIComponent(state.id))
          .then(function(r){ return r.json(); })
          .then(function(j){
            if(j.ok){
              state.messages = j.chat.messages || state.messages;
              state.title = j.chat.title || state.title;
              setHeader();
              rerenderMessages();
            }
            loadHistory();
          }).catch(function(){ loadHistory(); });
      } else {
        loadHistory();
      }
    }, 300);
  };
}

function sendOrStop(){
  if(state.generating){
    stopGeneration(false);
    return;
  }
  const t=els.input.value.trim();
  if(!t && state.attachments.length===0) return;
  const finalText = t || '请分析我上传的附件';
  els.input.value='';
  sendWithText(finalText,false);
}

function enableChatTitleEdit(){
  els.chatTitle.ondblclick=function(){
    if(!state.id) return;
    const input=document.createElement('input');
    input.value=state.title||'新会话';
    input.className='btn';
    input.style.fontSize='18px';
    input.style.width='260px';
    const parent=els.chatTitle.parentElement;
    parent.replaceChild(input,els.chatTitle);
    input.focus();
    input.select();

    const save=function(){
      const t=input.value.trim()||'新会话';
      fetch('?action=rename',{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        body:JSON.stringify({id:state.id,title:t})
      }).then(function(){
        state.title=t;
        setHeader();
        parent.replaceChild(els.chatTitle,input);
        loadHistory();
        enableChatTitleEdit();
      });
    };

    input.addEventListener('blur',save,{once:true});
    input.addEventListener('keydown',function(e){
      if(e.key==='Enter') input.blur();
      if(e.key==='Escape'){
        parent.replaceChild(els.chatTitle,input);
        enableChatTitleEdit();
      }
    });
  };
}

function renderOverviewRichMessage(m){
  return '<div class="msg-content">' + md(normalizeLatexText(m.content || '')) + '</div>' + (m.role === 'user' ? renderUserAttachments(m) : '');
}

function openOverview(){
  if(!state.id && state.messages.length === 0) {
    alert('当前没有聊天记录');
    return;
  }
  setModalFullscreenBtn(els.overviewFullscreenBtn, els.overviewModal.classList.contains('fullscreen'));
  els.overviewModalMask.style.display = 'flex';
  els.overviewSearchInput.value = '';
  renderOverview('');
}
function closeOverview(){
  els.overviewModalMask.style.display = 'none';
  resetModalFullscreen(els.overviewModal, els.overviewFullscreenBtn);
}
function renderOverview(keyword){
  const container = els.overviewContent;
  container.innerHTML = '';
  const msgs = state.messages;
  if(msgs.length === 0){
    container.innerHTML = '<div style="text-align:center; color:#666; padding:20px;">当前会话无消息</div>';
    return;
  }

  const kw = keyword ? keyword.trim() : '';
  const kwLower = kw ? kw.toLowerCase() : '';
  const list = [];

  if (kwLower) {
    msgs.forEach(function(m, idx){
      const content = m.content || '';
      if (content.toLowerCase().indexOf(kwLower) !== -1) list.push(idx);
    });
  } else {
    for(let i=0; i<msgs.length; i++) list.push(i);
  }

  if (list.length === 0) {
    container.innerHTML = '<div style="text-align:center; color:#666; padding:20px;">未找到匹配内容</div>';
    return;
  }

  list.forEach(function(idx){
    const m = msgs[idx];
    const content = m.content || '';
    const item = document.createElement('div');
    item.className = 'overview-item';
    const role = m.role === 'user' ? 'User' : (prettyModelName(m.model) || 'Assistant');

    let html = '<div class="overview-item-header">';
    html += '<span class="overview-item-role">' + esc(role) + '</span>';
    html += '<div class="overview-item-actions">';
    html += '<button class="btn iconbtn overview-copy" data-idx="'+idx+'">复制</button>';
    html += '<button class="btn iconbtn overview-jump" data-idx="'+idx+'">跳转</button>';
    html += '<button class="btn iconbtn overview-expand">展开</button>';
    html += '</div></div>';
    html += '<div class="overview-item-content">';

    if (kw) {
      let previewContent = content;
      if (content.length > 500) previewContent = content.slice(0, 500);
      html += '<div class="overview-item-preview">' + highlightAll(previewContent, kw) + '</div>';
      html += '<div class="overview-item-full" style="display:none;">' + highlightAll(content, kw) + '</div>';
    } else {
      html += '<div class="overview-item-preview">' + renderOverviewRichMessage(m) + '</div>';
      html += '<div class="overview-item-full" style="display:none;">' + renderOverviewRichMessage(m) + '</div>';
    }

    html += '</div>';
    item.innerHTML = html;

    const expandBtn = item.querySelector('.overview-expand');
    const previewDiv = item.querySelector('.overview-item-preview');
    const fullDiv = item.querySelector('.overview-item-full');

    if (!kw) {
      renderRich(previewDiv);
      renderRich(fullDiv);
    }

    item.querySelector('.overview-copy').onclick = function(){
      copyText(content).then(() => {
        const old = this.textContent;
        this.textContent = '已复制';
        this.style.color = '#111';
        setTimeout(() => {
          this.textContent = old;
          this.style.color = '';
        }, 1200);
      });
    };

    expandBtn.onclick = function(){
      if(fullDiv.style.display === 'none'){
        fullDiv.style.display = 'block';
        previewDiv.style.display = 'none';
        expandBtn.textContent = '收起';
      } else {
        fullDiv.style.display = 'none';
        previewDiv.style.display = '';
        expandBtn.textContent = '展开';
      }
    };

    item.querySelector('.overview-jump').onclick = function(){
      const targetIdx = Number(this.dataset.idx);
      closeOverview();
      state.autoScroll = false;
      setTimeout(function(){
        const target = els.msgs.querySelector('.msg[data-idx="'+targetIdx+'"]');
        if(target){
          target.scrollIntoView({ behavior:'smooth', block:'center' });
          target.style.boxShadow = '0 0 0 2px rgba(0,0,0,.25)';
          setTimeout(function(){ target.style.boxShadow=''; }, 1200);
        }
      }, 50);
    };

    container.appendChild(item);
  });
}

els.msgs.addEventListener('scroll', function(){
  const threshold = 50;
  const scrollTop = els.msgs.scrollTop;
  const scrollHeight = els.msgs.scrollHeight;
  const clientHeight = els.msgs.clientHeight;
  const isAtBottom = scrollHeight - scrollTop - clientHeight < threshold;
  if(isAtBottom) state.autoScroll = true;
  else if(state.autoScroll) state.autoScroll = false;
});

els.sendBtn.onclick=sendOrStop;
els.input.addEventListener('keydown',function(e){
  if(e.key==='Enter'&&!e.shiftKey){
    e.preventDefault();
    sendOrStop();
  }
});

els.openSideBtn.onclick = function(){
  if(window.innerWidth <= 860) openSide();
  else document.querySelector('.app').classList.toggle('sidebar-closed');
};

els.backdrop.onclick=closeSide;
els.newBtn.onclick=newChat;
els.searchBtn.onclick=function(){ setSearchMode(!state.searchMode); };
els.searchInput.oninput = function(){
  state.searchKey = els.searchInput.value.trim();
  loadHistory();
};

els.bulkModeBtn.onclick=function(){
  state.bulkMode=true;
  state.selected.clear();
  updateBulkUI();
  renderHistory();
};
els.bulkCancelBtn.onclick=function(){
  state.bulkMode=false;
  state.selected.clear();
  updateBulkUI();
  renderHistory();
};
els.selectAllBtn.onclick=toggleSelectAll;

els.bulkPinBtn.onclick=function(){
  const ids=[...state.selected];
  if(!ids.length) return alert('未选择');
  fetch('?action=bulk_pin',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ids:ids,pin:true})
  }).then(function(){
    state.selected.clear();
    loadHistory();
  });
};
els.bulkUnpinBtn.onclick=function(){
  const ids=[...state.selected];
  if(!ids.length) return alert('未选择');
  fetch('?action=bulk_pin',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ids:ids,pin:false})
  }).then(function(){
    state.selected.clear();
    loadHistory();
  });
};
els.bulkDelBtn.onclick=function(){
  const ids=[...state.selected];
  if(!ids.length) return alert('未选择');
  if(!confirm('确认删除 ' + ids.length + ' 个会话？')) return;
  fetch('?action=bulk_delete',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({ids:ids})
  }).then(function(){
    if(state.id&&ids.includes(state.id)) newChat();
    state.selected.clear();
    loadHistory();
  });
};

els.wideModeBtn.onclick=function(){
  setWideMode(!state.wideMode);
};

els.uploadBtn.onclick=function(){ els.fileInput.click(); };
els.fileInput.onchange=function(){
  handleSelectedFiles(els.fileInput.files);
  els.fileInput.value='';
};

els.editFullscreenBtn.onclick = function(){ toggleModalFullscreen(els.editModal, els.editFullscreenBtn); };
els.reasoningFullscreenBtn.onclick = function(){ toggleModalFullscreen(els.reasoningModal, els.reasoningFullscreenBtn); };
els.overviewFullscreenBtn.onclick = function(){ toggleModalFullscreen(els.overviewModal, els.overviewFullscreenBtn); };

els.editCancelBtn.onclick = closeEditModal;
els.editSaveBtn.onclick = function(){
  if (state.editingIndex < 0) return;
  const idx = state.editingIndex;
  state.messages[idx].content = els.editModalText.value;
  persistMessages().then(function(){
    closeEditModal();
    updateMessageContentDom(idx);
  });
};
els.editModalMask.onclick = function(e){
  if (e.target === els.editModalMask) closeEditModal();
};

els.reasoningCloseBtn.onclick = closeReasoningModal;
els.reasoningEditBtn.onclick = toggleReasoningEdit;
els.reasoningModalMask.onclick = function(e){
  if (e.target === els.reasoningModalMask) closeReasoningModal();
};

els.overviewBtn.onclick = openOverview;
els.overviewCloseBtn.onclick = closeOverview;
els.overviewModalMask.onclick = function(e){
  if (e.target === els.overviewModalMask) closeOverview();
};
els.overviewSearchInput.oninput = function(){
  renderOverview(els.overviewSearchInput.value);
};

(function init(){
  loadModels().then(function(){
    setHeader();
    setSendBtn();
    updateBulkUI();
    enableChatTitleEdit();
    renderAttachmentList();
    bindInputDragUpload();
    setModalFullscreenBtn(els.editFullscreenBtn, false);
    setModalFullscreenBtn(els.reasoningFullscreenBtn, false);
    setModalFullscreenBtn(els.overviewFullscreenBtn, false);
    setWideMode(false);
    loadHistory();
  }).catch(function(e){
    console.error(e);
    alert('初始化失败，请打开控制台查看错误');
  });
})();
</script>
</body>
</html>